contract SimpleCalldata {
    function processCalldata(uint id, string calldata name) external pure returns (uint) {
        return id + bytes(name).length;
    }
}