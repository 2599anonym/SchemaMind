contract SimpleAddressSetLib {
    struct Set {
        mapping(address => bool) contains;
        address[] members;
    }
    function add(Set storage set, address value) internal {
        if (!set.contains[value]) {
            set.contains[value] = true;
            set.members.push(value);
        }
    }
}