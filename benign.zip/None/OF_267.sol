contract SimpleStorageV2 {
    mapping(address => bytes) public userData;
    function storeMyData(bytes memory data) public {
        userData[msg.sender] = data;
    }
}