contract SimplePaymentForwarder {
    address payable private _destination;
    function forwardFunds() public payable {
        _destination.transfer(msg.value);
    }
}