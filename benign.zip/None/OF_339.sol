contract FallbackReceiver {
    event Received(address sender, uint amount);
    fallback() external payable {
        emit Received(msg.sender, msg.value);
    }
}