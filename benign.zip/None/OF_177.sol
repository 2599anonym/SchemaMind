contract SimpleBurnFrom {
    mapping(address => uint) balances;
    mapping(address => mapping(address => uint)) allowances;
    function burnFrom(address from, uint amount) public {
        require(balances[from] >= amount && allowances[from][msg.sender] >= amount);
        balances[from] -= amount;
        allowances[from][msg.sender] -= amount;
    }
}