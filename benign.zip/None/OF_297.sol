contract SimpleConditionalExecutor {
    bool public shouldExecute;
    function execute() public {
        require(shouldExecute, "Condition not met");
        // execution logic
    }
}