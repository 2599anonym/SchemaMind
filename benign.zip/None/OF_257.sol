contract Quota {
    mapping(address => uint) public usage;
    uint public constant DAILY_QUOTA = 10;
    function useQuota(uint amount) public {
        require(usage[msg.sender] + amount <= DAILY_QUOTA);
        usage[msg.sender] += amount;
    }
}