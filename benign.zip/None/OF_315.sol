contract SimpleAddressCheckerV2 {
    function isZeroAddress(address _addr) public pure returns (bool) {
        return _addr == address(0);
    }
}