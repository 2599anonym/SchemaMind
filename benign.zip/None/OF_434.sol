contract DataFeed {
    uint public latestData;
    function updateData(uint newData) public {
        latestData = newData;
    }
}