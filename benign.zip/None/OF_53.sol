contract SimpleEscrowAgent {
    address public agent;
    function release() public {
        require(msg.sender == agent, "Only agent can release");
        // release logic
    }
}