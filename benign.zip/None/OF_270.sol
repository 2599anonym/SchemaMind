contract SimpleBytes32Registry {
    mapping(bytes32 => bool) public registry;
    function register(bytes32 item) public {
        registry[item] = true;
    }
}