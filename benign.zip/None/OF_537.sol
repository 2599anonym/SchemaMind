contract SimpleCheckpointV2 {
    mapping(uint256 => uint256) public checkpoints;
    function createCheckpoint(uint256 id, uint256 value) public {
        checkpoints[id] = value;
    }
}