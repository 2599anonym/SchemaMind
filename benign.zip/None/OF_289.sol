contract SimpleRoleGranter {
    mapping(bytes32 => mapping(address => bool)) public roles;
    function grantRole(bytes32 role, address account) public {
        // requires admin role
        roles[role][account] = true;
    }
}