contract BasicConverter {
    uint256 public conversionRate = 10;
    function convert(uint256 amount) public pure returns (uint256) {
        uint256 result = amount * conversionRate;
        require(result / amount == conversionRate, "Overflow in conversion");
        return result;
    }
}