contract LinearVesting {
    uint256 public startAmount;
    uint256 public vestingDuration;
    function releaseableAmount() public view returns (uint256) {
        // vesting calculation
        return 0;
    }
}