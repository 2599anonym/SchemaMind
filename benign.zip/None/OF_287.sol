contract SimpleTimeDelay {
    uint256 public constant DELAY_IN_SECONDS = 3600;
    function getExecutionTime() public view returns (uint256) {
        return block.timestamp + DELAY_IN_SECONDS;
    }
}