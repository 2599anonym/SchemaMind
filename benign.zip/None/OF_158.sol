contract SimpleForwardingProxy {
    address public implementation;
    function forward() external payable {
        (bool s, ) = implementation.delegatecall(msg.data);
        require(s);
    }
}