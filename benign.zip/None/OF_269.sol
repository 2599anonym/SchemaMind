contract SimpleTimeRangeCheck {
    uint256 public startTime;
    uint256 public endTime;
    function isWithinRange(uint256 time) public view returns (bool) {
        return time >= startTime && time <= endTime;
    }
}