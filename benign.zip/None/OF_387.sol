contract SimpleDelete {
    mapping(address => uint) public balances;
    function clearBalance() public {
        delete balances[msg.sender];
    }
}