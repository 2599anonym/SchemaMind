contract SimpleWithdraw {
    mapping(address => uint256) public balances;
    function withdraw(uint256 amount) public {
        if (balances[msg.sender] >= amount) {
            balances[msg.sender] -= amount;
            msg.sender.transfer(amount);
        }
    }
}