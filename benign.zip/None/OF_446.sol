contract SimpleGame {
    uint public score;
    function increaseScore(uint points) public {
        score = score + points;
    }
}