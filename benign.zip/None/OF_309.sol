contract SimpleValueSetter {
    uint256 private _value;
    function set(uint256 newValue) public {
        _value = newValue;
    }
}