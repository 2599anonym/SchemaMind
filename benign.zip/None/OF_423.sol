contract Burnable {
    mapping(address => uint) balances;
    function burn(uint amount) public {
        if (balances[msg.sender] >= amount) {
            balances[msg.sender] -= amount;
        }
    }
}