contract SimpleDataPointer {
    bytes32 public pointer;
    function setPointer(bytes32 _pointer) public {
        pointer = _pointer;
    }
}