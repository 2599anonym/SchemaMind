contract ConditionalTransfer {
    bool public conditionMet = false;
    function transferIfMet(address recipient) public payable {
        if (conditionMet) {
            recipient.transfer(msg.value);
        }
    }
}