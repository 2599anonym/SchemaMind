contract SimpleMappingManager {
    mapping(address => uint256) private data;
    function setData(uint256 _value) public {
        data[msg.sender] = _value;
    }
}