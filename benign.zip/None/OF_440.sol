contract SimpleReceiveEth {
    receive() external payable {}
}