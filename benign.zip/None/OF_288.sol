contract SimpleETHVault {
    function deposit() external payable {
        // stores ETH
    }
}