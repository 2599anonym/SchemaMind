contract SimpleTimeProvider {
    function getTime() public view returns (uint256) {
        return block.timestamp;
    }
}