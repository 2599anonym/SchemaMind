contract SimpleRewardCalculator {
    uint256 public constant REWARD_MULTIPLIER = 10;
    function calculate(uint256 principal) public pure returns (uint256) {
        return principal * REWARD_MULTIPLIER;
    }
}