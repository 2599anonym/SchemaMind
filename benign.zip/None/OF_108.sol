contract SimpleDataStore {
    mapping(uint => string) public records;
    function setRecord(uint id, string memory data) public {
        records[id] = data;
    }
}