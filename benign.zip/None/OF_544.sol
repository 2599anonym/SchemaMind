contract SimpleDataVerificationV2 {
    function verify(bytes32 hash1, bytes32 hash2) public pure returns (bool) {
        return hash1 == hash2;
    }
}