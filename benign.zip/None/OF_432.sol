contract SimpleExternalCall {
    function callExternal(address target) public {
        (bool success, ) = target.call(abi.encodeWithSignature("someFunction()"));
        require(success);
    }
}