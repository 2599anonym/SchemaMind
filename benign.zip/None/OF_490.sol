contract DelegateCall {
    address public implementation;
    function execute(bytes memory data) public {
        (bool success, ) = implementation.delegatecall(data);
        require(success);
    }
}