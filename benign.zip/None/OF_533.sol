contract SimplePercentageV2 {
    function applyPercent(uint256 val, uint256 pct) public pure returns (uint256) {
        require(pct <= 100, "Percentage over 100");
        return (val * pct) / 100;
    }
}