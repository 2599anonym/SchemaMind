contract SimpleStaticcall {
    function readExternal(address target) public view returns(uint) {
        (bool success, bytes memory data) = target.staticcall(abi.encodeWithSignature("getValue()"));
        require(success);
        return abi.decode(data, (uint));
    }
}