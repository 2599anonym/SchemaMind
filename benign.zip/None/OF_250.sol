contract SimpleSignatureManager {
    mapping(bytes32 => bool) public usedSignatures;
    function markAsUsed(bytes32 _signatureHash) public {
        usedSignatures[_signatureHash] = true;
    }
}