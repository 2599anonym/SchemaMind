contract SimpleUserRegistry {
    address[] public users;
    mapping(address => bool) private isUser;
    function register() public {
        if (!isUser[msg.sender]) {
            isUser[msg.sender] = true;
            users.push(msg.sender);
        }
    }
}