contract SimpleEnumerableSet {
    // using EnumerableSet for EnumerableSet.AddressSet;
    // EnumerableSet.AddressSet private _mySet;
}