contract SimpleArrayManager {
    uint[] private values;
    function addValue(uint _val) public {
        values.push(_val);
    }
    function getValue(uint index) public view returns(uint) {
        return values[index];
    }
}