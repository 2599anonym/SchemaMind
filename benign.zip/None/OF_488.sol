contract SimpleVoteCounter {
    uint256 public ayes;
    uint256 public nays;
    function vote(bool inFavor) public {
        if (inFavor) {
            ayes++;
        } else {
            nays++;
        }
    }
}