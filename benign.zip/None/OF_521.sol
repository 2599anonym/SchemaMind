contract SimpleAuctionV3 {
    address public highestBidder;
    uint256 public highestBid;
    function getHighestBid() public view returns (address, uint256) {
        return (highestBidder, highestBid);
    }
}