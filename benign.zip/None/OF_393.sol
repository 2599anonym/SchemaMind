contract SimpleOverrideFunction is SimpleVirtualFunction {
    function myFunction() public override pure returns (uint) {
        return 2;
    }
}