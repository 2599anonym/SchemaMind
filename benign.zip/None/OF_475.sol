contract SimpleContractFactory {
    address[] public deployedContracts;
    function createChild() public {
        // ChildContract child = new ChildContract();
        // deployedContracts.push(address(child));
    }
}