contract DataAnchor {
    mapping(bytes32 => uint256) public anchors;
    function anchorData(bytes32 dataHash) public {
        if (anchors[dataHash] == 0) {
            anchors[dataHash] = block.timestamp;
        }
    }
}