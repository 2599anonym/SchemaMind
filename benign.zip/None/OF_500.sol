contract SimpleDataStoreV2 {
    mapping(bytes32 => bytes32) public data;
    function store(bytes32 key, bytes32 value) public {
        data[key] = value;
    }
}