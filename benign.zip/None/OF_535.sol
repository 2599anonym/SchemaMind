contract SimpleAddressWhitelistV2 {
    mapping(address => bool) private _whitelist;
    function addToWhitelist(address user) public {
        _whitelist[user] = true;
    }
}