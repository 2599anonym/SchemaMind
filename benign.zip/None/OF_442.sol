contract SimpleImmutable {
    address public immutable TOKEN_ADDRESS;
    constructor(address _token) {
        TOKEN_ADDRESS = _token;
    }
}