contract SimpleKeccak256 {
    function hash(string memory text) public pure returns (bytes32) {
        return keccak256(bytes(text));
    }
}