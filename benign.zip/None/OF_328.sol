contract SimpleContractDeployerV2 {
    address[] public deployed;
    function create() public {
        // NewContract c = new NewContract();
        // deployed.push(address(c));
    }
}