contract SimpleAuctionV2 {
    uint public auctionEndTime;
    function isAuctionOpen() public view returns (bool) {
        return block.timestamp < auctionEndTime;
    }
}