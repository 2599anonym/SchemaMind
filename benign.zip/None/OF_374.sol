contract SimpleTryCatch {
    function tryCall(address target) public {
        try IERC20(target).transfer(msg.sender, 100) {
            // success
        } catch {
            // failure
        }
    }
}