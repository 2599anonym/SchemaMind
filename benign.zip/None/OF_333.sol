contract SimpleMathV3 {
    function isEven(uint256 num) public pure returns (bool) {
        return num % 2 == 0;
    }
}