contract UserData {
    mapping(address => uint256) public userScores;
    function setScore(uint256 score) public {
        userScores[msg.sender] = score;
    }
}