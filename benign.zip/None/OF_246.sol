contract PaymentReceiver {
    event PaymentReceived(address from, uint amount);
    function receivePayment() public payable {
        emit PaymentReceived(msg.sender, msg.value);
    }
}