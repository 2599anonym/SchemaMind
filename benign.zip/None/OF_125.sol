contract SimpleRoleCheck {
    address public admin;
    function isAdmin() public view returns (bool) {
        return msg.sender == admin;
    }
}