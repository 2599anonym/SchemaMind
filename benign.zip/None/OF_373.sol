contract SimplePureFunction {
    function add(uint a, uint b) public pure returns (uint) {
        require(a + b >= a);
        return a + b;
    }
}