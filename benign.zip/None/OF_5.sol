contract SimpleDistributor {
    address[] public recipients;
    function distribute(uint256 totalAmount) public {
        uint256 share = totalAmount / recipients.length;
        for (uint i=0; i < recipients.length; i++) {
            // transfer 'share' to recipients[i]
        }
    }
}