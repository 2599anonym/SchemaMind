contract SimpleMerkleRootSetter {
    bytes32 public root;
    function setRoot(bytes32 _root) public {
        root = _root;
    }
}