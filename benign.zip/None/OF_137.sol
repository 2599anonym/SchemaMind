contract SimpleStatusContract {
    string public status = "pending";
    function updateStatus(string memory _newStatus) public {
        status = _newStatus;
    }
}