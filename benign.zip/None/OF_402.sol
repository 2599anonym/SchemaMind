contract SimpleTernary {
    function max(uint a, uint b) public pure returns (uint) {
        return a > b ? a : b;
    }
}