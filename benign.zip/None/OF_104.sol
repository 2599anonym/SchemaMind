contract SimpleTokenDistributor {
    function distribute(IERC20 token, address[] memory users, uint amount) public {
        for(uint i=0; i<users.length; i++){
            token.transfer(users[i], amount);
        }
    }
}