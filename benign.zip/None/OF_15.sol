contract MilestoneFunding {
    uint256 public currentMilestone;
    uint256[] public milestoneGoals;
    function fundNextMilestone() public payable {
        require(msg.value >= milestoneGoals[currentMilestone]);
        currentMilestone += 1;
    }
}