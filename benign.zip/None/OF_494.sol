contract SimpleDataFeedV2 {
    uint256 public latestValue;
    uint256 public lastUpdated;
    function update(uint256 value) public {
        latestValue = value;
        lastUpdated = block.timestamp;
    }
}