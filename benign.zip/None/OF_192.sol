contract SimpleContractDeployer {
    event Deployed(address addr);
    function deploy() public {
        // SimpleContract newContract = new SimpleContract();
        // emit Deployed(address(newContract));
    }
}