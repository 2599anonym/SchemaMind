contract SimpleWalletWithLimit {
    mapping(address => uint256) public dailyWithdrawals;
    uint256 public constant DAILY_LIMIT = 1 ether;

    function withdraw(uint256 amount) public {
        require(dailyWithdrawals[msg.sender] + amount <= DAILY_LIMIT);
        // withdrawal logic
    }
}