contract SimpleState {
    uint8 public state; // 0: inactive, 1: active
    function activate() public {
        state = 1;
    }
}