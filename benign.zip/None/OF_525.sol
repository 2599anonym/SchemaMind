contract SimplePaymentForwarderV2 {
    function forward() public payable {
        // requires destination address to be set
        // destination.transfer(msg.value);
    }
}