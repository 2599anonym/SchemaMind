contract SimpleEvent {
    event DataStored(uint256 indexed id, bytes32 data);
    function store(uint256 id, bytes32 data) public {
        emit DataStored(id, data);
    }
}