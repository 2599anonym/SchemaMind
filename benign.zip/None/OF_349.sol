contract BlockPropertyOracle {
    function getDifficulty() public view returns (uint) {
        return block.difficulty;
    }
    function getGasLimit() public view returns (uint) {
        return block.gaslimit;
    }
}