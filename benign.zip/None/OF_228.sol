contract StageManager {
    enum SaleStage { PreSale, MainSale, Ended }
    SaleStage public currentStage;
    function advanceToMainSale() public {
        if (currentStage == SaleStage.PreSale) {
            currentStage = SaleStage.MainSale;
        }
    }
}