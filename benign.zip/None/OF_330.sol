contract SimpleTieredAccessControl {
    mapping(address => uint8) public userLevel;
    modifier levelRequired(uint8 level) {
        require(userLevel[msg.sender] >= level, "Insufficient access level");
        _;
    }
}