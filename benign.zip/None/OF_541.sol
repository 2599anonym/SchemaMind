contract SimpleEscrowWithTimelockV2 {
    uint256 public releaseTime;
    function setReleaseTime(uint256 _releaseTime) public {
        require(_releaseTime > block.timestamp, "Must be in the future");
        releaseTime = _releaseTime;
    }
}