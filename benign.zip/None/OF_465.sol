contract SimpleReentrancyGuard {
    uint256 private status = 1;
    modifier nonReentrant() {
        require(status == 1, "ReentrancyGuard: reentrant call");
        status = 2;
        _;
        status = 1;
    }
}