contract SimpleEscrowWithConfirmation {
    bool public buyerConfirmed;
    bool public sellerConfirmed;
    function confirm() public {
        // set buyer or seller confirmation
    }
}