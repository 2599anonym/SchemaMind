contract FixedSupplyToken {
    uint256 public constant TOTAL_SUPPLY = 1_000_000 * 10**18;
    mapping(address => uint256) public balances;
}