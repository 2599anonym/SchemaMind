contract ConstantReader {
    uint256 public constant MY_CONSTANT = 42;
    function getConstant() public pure returns (uint256) {
        return MY_CONSTANT;
    }
}