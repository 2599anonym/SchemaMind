contract SimpleStorageStruct {
    struct Data { uint value; }
    Data public myData;
    function updateData(uint _value) public {
        myData.value = _value;
    }
}