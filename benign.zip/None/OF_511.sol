contract SimpleTimestampedData {
    struct DataPoint {
        uint256 value;
        uint256 timestamp;
    }
    mapping(uint256 => DataPoint) public data;

    function addDataPoint(uint256 id, uint256 value) public {
        data[id] = DataPoint(value, block.timestamp);
    }
}