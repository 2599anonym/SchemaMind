contract SimpleBatchApproval {
    IERC20 public token;
    function approveMany(address[] memory spenders, uint256 amount) public {
        for (uint i = 0; i < spenders.length; i++) {
            token.approve(spenders[i], amount);
        }
    }
}