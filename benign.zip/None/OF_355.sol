contract AddressStringUtil {
    function addressToString(address _addr) public pure returns (string memory) {
        // address to string conversion logic
        return "0x...";
    }
}