contract SimpleRateLimiter {
    mapping(address => uint256) public lastCall;
    uint256 public constant interval = 60 seconds;
    function call() public {
        require(block.timestamp >= lastCall[msg.sender] + interval, "Rate limit exceeded");
        lastCall[msg.sender] = block.timestamp;
    }
}