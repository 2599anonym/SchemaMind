contract SimpleMultisigWallet {
    address[] public owners;
    uint public requiredConfirmations;
    function isOwner(address account) public view returns (bool) {
        for(uint i=0; i<owners.length; i++){
            if(owners[i] == account) return true;
        }
        return false;
    }
}