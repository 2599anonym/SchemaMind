contract SimpleTimeRange {
    uint public start;
    uint public end;
    function isInRange() public view returns (bool) {
        return block.timestamp >= start && block.timestamp < end;
    }
}