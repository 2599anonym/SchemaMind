contract StaticArray {
    uint256[3] public values;
    function setValue(uint8 index, uint256 value) public {
        if (index < 3) {
            values[index] = value;
        }
    }
}