contract SimpleWallet {
    mapping(address => uint) public userFunds;
    function deposit() public payable {
        userFunds[msg.sender] += msg.value;
    }
}