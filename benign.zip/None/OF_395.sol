contract SimplePayableConstructor {
    constructor() payable {
        // logic on deployment with ETH
    }
}