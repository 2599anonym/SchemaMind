contract SimplePausable {
    bool private _paused;
    function pause() public {
        _paused = true;
    }
}