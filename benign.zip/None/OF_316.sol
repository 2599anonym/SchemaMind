contract SimpleNFTMinterV2 {
    uint256 public mintedCount;
    uint256 public constant MAX_SUPPLY = 10000;
    function mint() public {
        require(mintedCount < MAX_SUPPLY, "Max supply reached");
        mintedCount++;
    }
}