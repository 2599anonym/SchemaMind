contract SimplePriceOracleV2 {
    mapping(address => uint256) public prices;
    function setPrice(address token, uint256 price) public {
        prices[token] = price;
    }
}