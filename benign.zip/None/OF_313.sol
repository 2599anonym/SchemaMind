contract SimpleTokenHolderV2 {
    mapping(IERC20 => uint256) public tokenBalances;
    function recordBalance(IERC20 token) public {
        tokenBalances[token] = token.balanceOf(address(this));
    }
}