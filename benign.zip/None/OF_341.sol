contract NonceManager {
    mapping(address => uint256) public nonces;
    function incrementNonce() public {
        nonces[msg.sender]++;
    }
}