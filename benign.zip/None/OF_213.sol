contract SimpleTokenGatedVoting {
    IERC20 public voteToken;
    function vote() public {
        require(voteToken.balanceOf(msg.sender) > 0, "No voting power");
    }
}