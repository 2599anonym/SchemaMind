contract SimpleUpgradableProxy {
    address public implementation;
    function upgradeTo(address newImplementation) public {
        // requires access control
        implementation = newImplementation;
    }
}