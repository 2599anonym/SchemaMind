contract SimpleBlockhashStore {
    mapping(uint => bytes32) public blockhashes;
    function storeBlockhash() public {
        blockhashes[block.number - 1] = blockhash(block.number - 1);
    }
}