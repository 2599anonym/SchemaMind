contract SimpleMaximumValue {
    uint public maxValue;
    function updateValue(uint _newValue) public {
        if (_newValue > maxValue) {
            maxValue = _newValue;
        }
    }
}