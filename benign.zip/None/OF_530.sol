contract SimpleRoleCheckV2 {
    mapping(address => bool) public isUserRole;
    function checkRole(address user) public view returns (bool) {
        return isUserRole[user];
    }
}