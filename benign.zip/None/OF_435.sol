contract SimpleDeleteFromMemoryArray {
    // Cannot delete from memory arrays. This is just for demonstration.
    function process(uint[] memory data) public pure {
        // data[0] cannot be deleted
    }
}