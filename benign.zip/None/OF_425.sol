contract SimpleMappingWithStruct {
    struct UserProfile {
        bool active;
        uint256 score;
    }
    mapping(address => UserProfile) public profiles;
    function activateUser() public {
        profiles[msg.sender].active = true;
    }
}