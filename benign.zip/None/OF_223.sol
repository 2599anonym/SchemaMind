contract Vesting {
    uint256 public cliffDate;
    function unlockTokens() public {
        if (block.timestamp < cliffDate) {
            revert();
        }
    }
}