contract SimpleLinearReward {
    uint256 public constant REWARD_PER_BLOCK = 10;
    uint256 public startBlock;
    function calculateReward() public view returns (uint256) {
        if (block.number <= startBlock) return 0;
        return (block.number - startBlock) * REWARD_PER_BLOCK;
    }
}