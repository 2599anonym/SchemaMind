contract SimpleAuctionEngine {
    uint256 public bidIncrement;
    uint256 public highestBid;
    function placeBid() public payable {
        require(msg.value >= highestBid + bidIncrement, "Bid too low");
        // update highest bid
    }
}