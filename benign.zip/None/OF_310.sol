contract SimpleBytesUtils {
    function toBytes32(string memory _str) public pure returns (bytes32) {
        return keccak256(abi.encodePacked(_str));
    }
}