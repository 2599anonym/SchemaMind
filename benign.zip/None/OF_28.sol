contract Manager {
    address public worker;
    function setWorker(address _worker) public {
        worker = _worker;
    }
}