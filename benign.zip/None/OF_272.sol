contract SimpleBalanceManager {
    mapping(address => uint256) private _balances;
    function getBalance(address user) public view returns (uint256) {
        return _balances[user];
    }
}