contract SimpleDataUpdater {
    string public data;
    event DataUpdated(string newData);
    function update(string memory _newData) public {
        data = _newData;
        emit DataUpdated(_newData);
    }
}