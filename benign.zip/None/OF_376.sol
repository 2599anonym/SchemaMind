contract SimplePrivateVar {
    uint256 private mySecretNumber;
    function setSecret(uint256 _num) public {
        // access control
        mySecretNumber = _num;
    }
}