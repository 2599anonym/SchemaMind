contract UserScore {
    mapping(address => uint8) private scores;
    function recordScore(uint8 _score) public {
        if (_score > scores[msg.sender]) {
            scores[msg.sender] = _score;
        }
    }
}