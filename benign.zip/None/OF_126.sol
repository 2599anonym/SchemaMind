contract SimpleValueLock {
    uint public amount;
    bool public locked;
    function lock() public {
        locked = true;
    }
}