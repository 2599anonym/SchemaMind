contract SimpleTokenRetriever {
    function retrieveTokens(IERC20 token, uint256 amount) public {
        token.transfer(msg.sender, amount);
    }
}