contract SimpleErrorHandling {
    error InsufficientBalance(uint required, uint available);
    function withdraw(uint amount) public {
        uint balance = 100; // dummy balance
        if (amount > balance) {
            revert InsufficientBalance(amount, balance);
        }
    }
}