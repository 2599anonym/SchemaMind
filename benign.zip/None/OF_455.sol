contract EIP712Checker {
    function hashTypedDataV4(bytes32 structHash) public view returns (bytes32) {
        // bytes32 DOMAIN_SEPARATOR = _domainSeparatorV4();
        // return keccak256(abi.encodePacked("\x19\x01", DOMAIN_SEPARATOR, structHash));
    }
}