contract SimpleAddressBook {
    mapping(string => address) public contacts;
    function addContact(string memory name, address contactAddress) public {
        contacts[name] = contactAddress;
    }
}