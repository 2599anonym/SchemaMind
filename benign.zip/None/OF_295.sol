contract SimpleNFTMetadataUpdater {
    function updateTokenURI(uint256 tokenId, string memory newUri) public {
        // requires owner or approved
        // _setTokenURI(tokenId, newUri);
    }
}