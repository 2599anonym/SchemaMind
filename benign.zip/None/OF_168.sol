contract SimpleEscrow {
    address public depositor;
    address public beneficiary;
    function releaseFunds() public {
        if (msg.sender == depositor) {
            beneficiary.transfer(address(this).balance);
        }
    }
}