contract SimpleAllowanceChanger {
    mapping(address => mapping(address => uint256)) public allowance;
    function changeAllowance(address spender, uint256 newAmount) public {
        allowance[msg.sender][spender] = newAmount;
    }
}