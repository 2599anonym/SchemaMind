contract Counter {
    uint public count;
    function increment() public {
        count = count + 1;
    }
}