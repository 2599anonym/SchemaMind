contract SimpleVault {
    function deposit() public payable {}

    function withdrawAll(address payable recipient) public {
        // access control needed
        recipient.transfer(address(this).balance);
    }
}