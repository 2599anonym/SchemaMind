contract SimpleProxyV2 {
    address public implementation;

    fallback() external payable {
        address impl = implementation;
        require(impl != address(0));
        assembly {
            // delegatecall logic
        }
    }
}