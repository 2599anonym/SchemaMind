contract ReturnValueForwarder {
    fallback() external payable returns (bytes memory) {
        // delegatecall and return data
    }
}