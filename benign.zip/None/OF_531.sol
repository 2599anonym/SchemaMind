contract SimpleValueLockV2 {
    uint256 public value;
    bool public locked;
    function setValue(uint256 _value) public {
        require(!locked, "Value is locked");
        value = _value;
    }
}