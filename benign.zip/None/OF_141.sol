contract SimpleCounterWithMax {
    uint8 public counter;
    uint8 public constant MAX_COUNT = 100;
    function increment() public {
        if (counter < MAX_COUNT) {
            counter++;
        }
    }
}