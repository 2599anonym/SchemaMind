contract StaticDataProvider {
    function getData() public pure returns (string memory) {
        return "Static Data";
    }
}