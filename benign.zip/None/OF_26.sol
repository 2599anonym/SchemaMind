contract Factory {
    event ContractCreated(address newContract);
    function deployNewContract() public {
        // SimpleContract c = new SimpleContract();
        // emit ContractCreated(address(c));
    }
}