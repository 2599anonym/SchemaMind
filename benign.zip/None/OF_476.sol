contract SimpleNFTMetadataRegistry {
    mapping(uint256 => string) private _tokenURIs;
    function tokenURI(uint256 tokenId) public view returns (string memory) {
        return _tokenURIs[tokenId];
    }
}