contract SimplePaymentProcessor {
    event Processed(address user, uint amount);
    function processPayment() public payable {
        emit Processed(msg.sender, msg.value);
    }
}