contract SimpleETHTransfer {
    function sendETH(address payable recipient, uint256 amount) public {
        recipient.transfer(amount);
    }
}