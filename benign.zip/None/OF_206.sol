contract SimpleBlockNumberLogger {
    uint[] public blockNumbers;
    function log() public {
        blockNumbers.push(block.number);
    }
}