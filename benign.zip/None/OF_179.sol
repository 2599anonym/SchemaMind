contract Approval {
    mapping(bytes32 => bool) public approvedHashes;
    function approveHash(bytes32 h) public {
        approvedHashes[h] = true;
    }
}