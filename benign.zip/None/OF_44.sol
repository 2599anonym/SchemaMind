contract SimpleAddressStore {
    address[] public addresses;
    function addAddress(address _addr) public {
        addresses.push(_addr);
    }
}