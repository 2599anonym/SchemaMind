contract SimpleOwner {
    address private _owner;
    modifier onlyOwner {
        require(msg.sender == _owner, "Not the owner");
        _;
    }
}