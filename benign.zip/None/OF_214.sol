contract SimpleStaticcallProxy {
    address public implementation;
    fallback() external {
        (bool s, bytes memory r) = implementation.staticcall(msg.data);
        require(s);
        assembly { return(add(r, 0x20), mload(r)) }
    }
}