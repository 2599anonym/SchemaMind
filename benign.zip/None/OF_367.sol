contract SimpleFunctionSelector {
    function getSelector(string memory func) public pure returns (bytes4) {
        return bytes4(keccak256(bytes(func)));
    }
}