contract SimpleNFTRegistry {
    mapping(uint256 => address) private _tokenOwners;
    function ownerOf(uint256 tokenId) public view returns (address) {
        return _tokenOwners[tokenId];
    }
}