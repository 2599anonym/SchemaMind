contract SimpleDataConfirm {
    mapping(bytes32 => bool) confirmations;
    function confirmData(bytes32 dataHash) public {
        confirmations[dataHash] = true;
    }
}