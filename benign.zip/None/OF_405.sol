contract SimpleBytesManipulation {
    function getFirstByte(bytes memory b) public pure returns (byte) {
        if (b.length == 0) return 0;
        return b[0];
    }
}