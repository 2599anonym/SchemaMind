contract SimpleGlobalVars {
    function getTxOrigin() public view returns (address) {
        return tx.origin;
    }
}