contract SimpleEventIndexer {
    event ValueSet(uint256 indexed key, uint256 value);
    function setValue(uint256 key, uint256 value) public {
        emit ValueSet(key, value);
    }
}