contract SimpleBalanceTracker {
    mapping(address => uint256) public trackedBalances;
    function trackBalance(address user, uint256 amount) public {
        trackedBalances[user] = amount;
    }
}