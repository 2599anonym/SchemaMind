contract MaxBalance {
    mapping(address => uint) public balances;
    uint public constant MAX_BALANCE = 100 ether;
    function deposit() public payable {
        require(balances[msg.sender] + msg.value <= MAX_BALANCE);
        balances[msg.sender] += msg.value;
    }
}