contract SimpleLibrary {
    library MathLib {
        function add(uint a, uint b) internal pure returns (uint) {
            uint c = a + b;
            require(c >= a);
            return c;
        }
    }
}