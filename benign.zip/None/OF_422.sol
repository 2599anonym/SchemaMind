contract SimpleBitwiseOps {
    function hasFlag(uint256 flags, uint256 flag) public pure returns (bool) {
        return (flags & flag) == flag;
    }
}