contract BytesSlicer {
    function slice(bytes memory _bytes, uint256 _start, uint256 _length) public pure returns (bytes memory) {
        require(_start + _length <= _bytes.length, "Slice out of bounds");
        bytes memory temp = new bytes(_length);
        // copy bytes logic
        return temp;
    }
}