contract Whitelist {
    mapping(address => bool) public isWhitelisted;
    function addToWhitelist(address user) public {
        isWhitelisted[user] = true;
    }
}