contract SimplePercentage {
    uint256 public feePercent = 5;
    function calculateFee(uint256 amount) public view returns (uint256) {
        return (amount * feePercent) / 100;
    }
}