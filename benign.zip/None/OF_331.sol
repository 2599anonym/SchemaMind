contract SimpleFeeCollectorV2 {
    address public collector;
    uint256 public feeRate;
    function collect(uint256 amount) internal {
        uint256 fee = amount * feeRate / 100;
        // transfer fee to collector
    }
}