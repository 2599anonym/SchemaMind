contract SimpleArrayInStruct {
    struct DataSet {
        string name;
        uint[] values;
    }
    DataSet public myData;
    function addValue(uint _value) public {
        myData.values.push(_value);
    }
}