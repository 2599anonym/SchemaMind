contract TimeLimited {
    uint256 public immutable creationTime;
    uint256 public constant DURATION = 7 days;
    constructor() {
        creationTime = block.timestamp;
    }
    function isExpired() public view returns (bool) {
        return block.timestamp >= creationTime + DURATION;
    }
}