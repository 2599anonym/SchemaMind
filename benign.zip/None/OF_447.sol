contract SimpleConstructorParams {
    uint public value;
    constructor(uint _initialValue) {
        value = _initialValue;
    }
}