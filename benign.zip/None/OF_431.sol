contract SimpleFunctionOverloading {
    function process(uint a) public pure returns (uint) {
        return a * 2;
    }
    function process(uint a, uint b) public pure returns (uint) {
        return a + b;
    }
}