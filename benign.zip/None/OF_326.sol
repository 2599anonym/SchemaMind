contract SimpleCapManager {
    uint256 public cap;
    function setCap(uint256 _newCap) public {
        // access control
        cap = _newCap;
    }
}