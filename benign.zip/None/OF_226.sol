contract OwnerBasedAccess {
    address public contractOwner;
    modifier onlyContractOwner() {
        require(msg.sender == contractOwner, "Caller is not the owner");
        _;
    }
}