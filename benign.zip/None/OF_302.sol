contract SimplePriceFeedReader {
    IPriceFeed public feed;
    function read() public view returns (int256) {
        return feed.read();
    }
}