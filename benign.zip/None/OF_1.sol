contract Token {
    mapping(address => uint256) public balances;
    function transfer(address _to, uint256 _value) public {
        if (balances[msg.sender] >= _value) {
            balances[msg.sender] -= _value;
            balances[_to] += _value;
        }
    }
}