contract SimpleTimeLimitedAction {
    uint public actionDeadline;
    function performAction() public {
        require(block.timestamp < actionDeadline, "Action window closed");
    }
}