contract SimpleRewarder {
    function calculateReward(uint stakedAmount) public pure returns (uint) {
        return stakedAmount / 10;
    }
}