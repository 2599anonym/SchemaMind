contract SimpleDataHashV2 {
    mapping(string => bytes32) public hashes;
    function hashData(string memory data) public {
        hashes[data] = keccak256(abi.encodePacked(data));
    }
}