contract AddressSet {
    address[] public members;
    mapping(address => bool) public isMember;
    function addMember(address _newMember) public {
        if (!isMember[_newMember]) {
            isMember[_newMember] = true;
            members.push(_newMember);
        }
    }
}