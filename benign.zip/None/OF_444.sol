contract SimpleSuperCall {
    // See previous example
    function logAndCallSuper() public {
        // emit Logged("Derived");
        // super.log();
    }
}