contract SimpleApprovalQueueV2 {
    struct Approval {
        address user;
        uint256 amount;
    }
    Approval[] public queue;
    function requestApproval(uint256 amount) public {
        queue.push(Approval(msg.sender, amount));
    }
}