contract BalanceChecker {
    function checkBalance() public view returns (uint) {
        return address(this).balance;
    }
}