contract ETHSplitter {
    address payable recipientA;
    address payable recipientB;
    function splitPayment() public payable {
        uint256 amount = msg.value / 2;
        recipientA.transfer(amount);
        recipientB.transfer(msg.value - amount);
    }
}