contract SimpleFixedSizeArray {
    uint[8] public myFixedArray;
    function set(uint index, uint value) public {
        require(index < 8, "Index out of bounds");
        myFixedArray[index] = value;
    }
}