contract SimpleBlockhash {
    function getRecentBlockhash() public view returns (bytes32) {
        return blockhash(block.number - 1);
    }
}