contract SimpleAverager {
    function average(uint256 a, uint256 b) public pure returns (uint256) {
        uint256 sum = a + b;
        require(sum >= a, "Addition overflow");
        return sum / 2;
    }
}