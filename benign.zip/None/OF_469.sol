contract SimpleERC1155 {
    mapping(address => mapping(uint256 => uint256)) public balanceOf;
    function safeTransferFrom(address from, address to, uint256 id, uint256 amount, bytes memory data) public {
        require(balanceOf[from][id] >= amount, "Insufficient balance");
        balanceOf[from][id] -= amount;
        balanceOf[to][id] += amount;
    }
}