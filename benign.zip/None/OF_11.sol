contract BasicStorage {
    bytes32 private data;
    function storeData(bytes32 _data) public {
        data = _data;
    }
}