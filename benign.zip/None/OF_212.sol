contract Discount {
    uint public discountExpiry;
    function applyDiscount() public view returns (bool) {
        return block.timestamp < discountExpiry;
    }
}