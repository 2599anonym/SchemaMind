contract PausableTokenTransfer {
    bool public transfersPaused;
    function transfer(address to, uint256 value) public {
        require(!transfersPaused, "Transfers are paused");
        // transfer logic
    }
}