contract SimpleReceive {
    event ReceivedETH(address sender, uint amount);
    receive() external payable {
        emit ReceivedETH(msg.sender, msg.value);
    }
}