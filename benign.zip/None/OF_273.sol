contract SimpleNFTCreator {
    uint256 private _nextTokenId;
    function createNFT(address owner) public {
        // _mint(owner, _nextTokenId);
        _nextTokenId++;
    }
}