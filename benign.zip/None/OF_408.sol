contract SimpleGasPrice {
    function getGasPrice() public view returns (uint) {
        return tx.gasprice;
    }
}