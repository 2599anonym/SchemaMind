contract SimpleEventData {
    event UserRegistered(address user, uint256 timestamp);
    function register() public {
        emit UserRegistered(msg.sender, block.timestamp);
    }
}