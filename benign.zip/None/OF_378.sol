contract SimpleEnum {
    enum Options { None, OptionA, OptionB }
    Options public choice;
    function choose(Options _choice) public {
        choice = _choice;
    }
}