contract SimpleBytes32Storage {
    bytes32[] public data;
    function addData(bytes32 _data) public {
        data.push(_data);
    }
}