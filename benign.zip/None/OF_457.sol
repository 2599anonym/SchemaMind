contract AddressStorage {
    address public storedAddress;
    function setAddress(address _newAddress) public {
        storedAddress = _newAddress;
    }
}