contract SimpleFlashLoan {
    function flashLoan(address receiver, uint256 amount) public {
        // transfer amount to receiver
        // IFlashLoanReceiver(receiver).executeOperation(amount);
        // require(token.balanceOf(address(this)) >= initialBalance);
    }
}