contract SimplePaymentSplitterV2 {
    address[] public payees;
    uint[] public shares;
    function release(address payable account) public {
        // release logic
    }
}