contract Ownership {
    address public currentOwner;
    function claimOwnership() public {
        currentOwner = msg.sender;
    }
}