contract SimpleChainId {
    uint256 public chainId;
    constructor() {
        uint256 id;
        assembly {
            id := chainid()
        }
        chainId = id;
    }
}