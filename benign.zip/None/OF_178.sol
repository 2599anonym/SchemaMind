contract SimpleTokenMinter {
    address public minter;
    function mint(address to, uint amount) public {
        require(msg.sender == minter, "Not the minter");
        // minting logic
    }
}