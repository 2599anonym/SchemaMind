contract SimpleGasCheck {
    function checkGasLeft() public view returns (uint) {
        return gasleft();
    }
}