contract SimpleMultiReturn {
    function getValues() public pure returns (uint, uint, uint) {
        return (1, 2, 3);
    }
}