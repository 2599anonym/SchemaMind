contract SimpleInternalFunc {
    function _internalAction() internal pure returns(bool) {
        return true;
    }
    function externalAction() public pure returns(bool) {
        return _internalAction();
    }
}