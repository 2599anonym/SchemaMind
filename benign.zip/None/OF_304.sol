contract SimpleWeightedVote {
    mapping(address => uint256) public voteWeight;
    uint256 public totalVotes;
    function vote() public {
        uint256 weight = voteWeight[msg.sender];
        totalVotes += weight;
    }
}