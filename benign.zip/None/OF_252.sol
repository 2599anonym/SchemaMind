contract SimpleTokenInterfaceV2 {
    event Approval(address indexed owner, address indexed spender, uint256 value);
    function approve(address spender, uint256 value) public returns (bool);
}