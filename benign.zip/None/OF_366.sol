contract SimpleMappingIterator {
    // Note: Iterating mappings directly is not possible.
    // This requires an auxiliary array of keys.
    address[] public keys;
    mapping(address => uint) public values;
    function set(uint value) public {
        if (values[msg.sender] == 0) {
            keys.push(msg.sender);
        }
        values[msg.sender] = value;
    }
}