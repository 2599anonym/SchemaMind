contract SimpleAllowanceReset {
    mapping(address => uint) allowances;
    function resetAllowance() public {
        allowances[msg.sender] = 0;
    }
}