contract BlockNumberBased {
    uint256 public startBlock;
    function hasStarted() public view returns (bool) {
        return block.number >= startBlock;
    }
}