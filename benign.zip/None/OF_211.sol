contract SimpleRefundEscrow {
    address public refundAddress;
    function setRefundAddress(address _addr) public {
        refundAddress = _addr;
    }
}