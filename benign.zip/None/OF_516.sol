contract SimpleStatefulV3 {
    bool public isInitialized;
    function initialize() public {
        require(!isInitialized, "Already initialized");
        isInitialized = true;
    }
}