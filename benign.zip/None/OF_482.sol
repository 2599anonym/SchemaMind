contract SimpleCappedTokenMint {
    uint256 public totalSupply;
    uint256 public immutable cap;
    function mint(uint256 amount) public {
        require(totalSupply + amount <= cap, "Cap exceeded");
        totalSupply += amount;
    }
}