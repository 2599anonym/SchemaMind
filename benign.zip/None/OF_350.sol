contract SafeMathConsumer {
    // using SafeMath for uint256;
    uint256 public value;
    function addValue(uint256 _add) public {
        // value = value.add(_add);
    }
}