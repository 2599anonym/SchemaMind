contract SimpleContractLocker {
    bool private locked;
    function lock() public {
        locked = true;
    }
    function isLocked() public view returns (bool) {
        return locked;
    }
}