contract SimpleInheritance is Pausable {
    function doSomethingPausable() public whenNotPaused {
        // some logic
    }
}