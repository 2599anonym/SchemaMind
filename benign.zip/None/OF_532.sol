contract SimpleTokenBurnerV3 {
    // using ERC20Burnable for IERC20;
    // IERC20 public token;
    function burn(uint256 amount) public {
        // token.burn(amount);
    }
}