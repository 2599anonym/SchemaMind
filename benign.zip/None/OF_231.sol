contract NFTApprovalManager {
    mapping(uint256 => address) private approvedAddresses;
    function approveToken(address _approved, uint256 _tokenId) public {
        // requires ownership check
        approvedAddresses[_tokenId] = _approved;
    }
}