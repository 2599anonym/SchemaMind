contract TokenTimelock {
    IERC20 private _token;
    address private _beneficiary;
    uint256 private _releaseTime;
    function release() public {
        require(block.timestamp >= _releaseTime, "Tokens are locked");
        _token.transfer(_beneficiary, _token.balanceOf(address(this)));
    }
}