contract Multiplier {
    uint public factor = 2;
    function calculate(uint value) public view returns (uint) {
        return value * factor;
    }
}