contract SimpleDestructuring {
    function processTuple() public {
        (uint id, bool status) = (1, true);
        // use id and status
    }
}