contract SimpleStakingRewards {
    uint256 public rewardRate;
    uint256 public lastUpdateTime;
    function rewardsPerToken() public view returns (uint256) {
        if (lastUpdateTime == 0) return 0;
        return (block.timestamp - lastUpdateTime) * rewardRate;
    }
}