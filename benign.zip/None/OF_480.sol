contract SimpleBytes32Array {
    bytes32[] public items;
    function add(bytes32 item) public {
        items.push(item);
    }
}