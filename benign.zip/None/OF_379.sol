contract Refundable {
    uint public deadline;
    function claimRefund() public {
        require(block.timestamp > deadline);
    }
}