contract ReentrancyGuardV2 {
    bool internal locked;
    modifier noReentry() {
        require(!locked, "No re-entrancy");
        locked = true;
        _;
        locked = false;
    }
}