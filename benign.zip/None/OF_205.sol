contract SimpleNFTMetadata {
    mapping(uint256 => string) public tokenURIs;
    function setTokenURI(uint256 tokenId, string memory uri) public {
        // owner check
        tokenURIs[tokenId] = uri;
    }
}