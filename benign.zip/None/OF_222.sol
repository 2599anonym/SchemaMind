contract SimpleTokenWrapper {
    IERC20 public underlying;
    function wrap() public payable {
        // logic to deposit ETH and get token
    }
}