contract SimpleStatefulContract {
    enum Status {A, B, C}
    Status public status;
    function nextState() public {
        if (status == Status.A) status = Status.B;
        else if (status == Status.B) status = Status.C;
    }
}