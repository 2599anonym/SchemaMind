contract SimpleDistributorWithFeeV2 {
    function distributeWithFee(uint256 total, uint256 feeBps) public pure returns (uint256) {
        uint256 fee = (total * feeBps) / 10000;
        return total - fee;
    }
}