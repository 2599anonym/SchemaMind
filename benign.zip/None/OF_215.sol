contract SimpleAddressSet {
    mapping(address => bool) private members;
    function add(address _member) public {
        members[_member] = true;
    }
    function contains(address _member) public view returns (bool) {
        return members[_member];
    }
}