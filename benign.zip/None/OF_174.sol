contract SimpleCalculation {
    function addAndMultiply(uint a, uint b, uint c) public pure returns (uint) {
        uint sum = a + b;
        require(sum >= a);
        uint product = sum * c;
        require(c == 0 || product / c == sum);
        return product;
    }
}