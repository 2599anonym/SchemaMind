contract SimpleTypeCasting {
    function toUint32(uint256 value) public pure returns (uint32) {
        require(value <= type(uint32).max, "Value too large");
        return uint32(value);
    }
}