contract FundsHolder {
    address public owner;
    function withdraw(uint amount) public {
        if (msg.sender == owner) {
            owner.transfer(amount);
        }
    }
}