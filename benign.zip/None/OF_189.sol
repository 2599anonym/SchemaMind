contract SimpleBalanceThreshold {
    mapping(address => uint) balances;
    uint constant MIN_BALANCE = 1 ether;
    function hasMinimumBalance() public view returns (bool) {
        return balances[msg.sender] >= MIN_BALANCE;
    }
}