contract SimpleConditionalReturn {
    function getStatus(uint256 value) public pure returns (string memory) {
        if (value > 100) {
            return "High";
        }
        return "Low";
    }
}