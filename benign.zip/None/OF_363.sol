contract SimpleReturnData {
    function getData() public pure returns (uint, bool) {
        return (123, true);
    }
}