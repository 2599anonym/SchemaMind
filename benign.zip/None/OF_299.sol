contract SimpleFeeManagerV2 {
    uint256 public basisPoints;
    function updateFee(uint256 _basisPoints) public {
        require(_basisPoints <= 10000, "Fee too high");
        basisPoints = _basisPoints;
    }
}