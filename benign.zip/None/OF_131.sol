contract SimpleCheckpoint {
    mapping(address => uint) public lastActionTime;
    function recordAction() public {
        lastActionTime[msg.sender] = block.timestamp;
    }
}