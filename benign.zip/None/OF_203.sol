contract SimpleContractToggler {
    bool public isEnabled;
    function toggle() public {
        // access control
        isEnabled = !isEnabled;
    }
}