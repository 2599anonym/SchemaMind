contract SimpleCampaign {
    uint public deadline;
    bool public isSuccessful;
    function finalize() public {
        if(block.timestamp > deadline) {
            // check if goal met
            isSuccessful = true;
        }
    }
}