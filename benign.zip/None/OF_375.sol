contract SimpleStructStorage {
    struct Config {
        uint rate;
        address owner;
    }
    Config public config;
    function setConfig(uint _rate) public {
        config.rate = _rate;
    }
}