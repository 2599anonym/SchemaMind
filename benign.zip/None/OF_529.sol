contract SimpleCampaignV2 {
    enum State { Fundraising, Successful, Failed }
    State public campaignState;
    function succeed() public {
        campaignState = State.Successful;
    }
}