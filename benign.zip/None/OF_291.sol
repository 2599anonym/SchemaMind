contract SimpleBurnable {
    mapping(address => uint256) private _balances;
    function burn(uint256 amount) public {
        require(_balances[msg.sender] >= amount, "Burn amount exceeds balance");
        _balances[msg.sender] -= amount;
        // update total supply
    }
}