contract SimpleRoleManager {
    mapping(address => bool) public isManager;
    modifier onlyManager {
        require(isManager[msg.sender], "Not a manager");
        _;
    }
}