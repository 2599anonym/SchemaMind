contract SimpleContractMetadata {
    function name() public pure returns (string memory) {
        return "MySimpleContract";
    }
}