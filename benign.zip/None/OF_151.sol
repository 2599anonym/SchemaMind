contract SimpleDonationCampaign {
    address payable public beneficiary;
    uint public goal;
    function donate() public payable {
        require(address(this).balance <= goal, "Goal reached");
    }
}