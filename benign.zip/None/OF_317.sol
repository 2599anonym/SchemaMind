contract SimpleEventFilter {
    event MyEvent(uint256 indexed id, bool indexed status);
    function triggerEvent(uint256 id, bool status) public {
        emit MyEvent(id, status);
    }
}