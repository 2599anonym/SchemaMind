contract SimpleTokenStaker {
    IERC20 public stakingToken;
    mapping(address => uint256) public stakes;
    function stakeTokens(uint256 amount) public {
        stakingToken.transferFrom(msg.sender, address(this), amount);
        stakes[msg.sender] += amount;
    }
}