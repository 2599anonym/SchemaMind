contract SimpleConditionalSend {
    function sendIf(address payable to, bool condition) public payable {
        if (condition) {
            to.transfer(msg.value);
        }
    }
}