contract AccessList {
    mapping(address => bool) private allowed;
    function grantAccess(address user) public {
        allowed[user] = true;
    }
}