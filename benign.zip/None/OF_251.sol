contract SimpleMapping {
    mapping(uint256 => string) public dataMap;
    function setData(uint256 key, string memory value) public {
        dataMap[key] = value;
    }
}