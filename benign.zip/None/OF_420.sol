contract SimpleAddressUtils {
    function isContract(address account) public view returns (bool) {
        return account.code.length > 0;
    }
}