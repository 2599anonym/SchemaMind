contract Cooldown {
    mapping(address => uint) public lastAction;
    uint public constant COOLDOWN_PERIOD = 1 days;
    function performAction() public {
        require(block.timestamp >= lastAction[msg.sender] + COOLDOWN_PERIOD);
        lastAction[msg.sender] = block.timestamp;
    }
}