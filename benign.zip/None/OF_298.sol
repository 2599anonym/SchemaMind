contract SimpleTokenFaucet {
    IERC20 public token;
    uint256 public dripAmount = 100;
    function requestTokens() public {
        token.transfer(msg.sender, dripAmount);
    }
}