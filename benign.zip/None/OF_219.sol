contract SimpleBalanceReader {
    function readBalance(address _addr) public view returns (uint) {
        return _addr.balance;
    }
}