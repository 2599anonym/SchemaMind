contract SimpleVestingSchedule {
    uint public start;
    uint public duration;
    function vestedFraction() public view returns (uint) {
        if (block.timestamp < start) return 0;
        if (block.timestamp >= start + duration) return 100;
        return ((block.timestamp - start) * 100) / duration;
    }
}