contract SimpleFlagV2 {
    mapping(address => bool) public userFlags;
    function setMyFlag(bool flag) public {
        userFlags[msg.sender] = flag;
    }
}