contract SimpleWhitelistManager {
    mapping(address => bool) public whitelisted;
    modifier onlyWhitelisted() {
        require(whitelisted[msg.sender], "Not on whitelist");
        _;
    }
}