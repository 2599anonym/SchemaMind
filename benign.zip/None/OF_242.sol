contract SimpleBeaconProxy {
    address public beacon;
    constructor(address _beacon) {
        beacon = _beacon;
    }
    fallback() external payable {
        // delegatecall to beacon's implementation
    }
}