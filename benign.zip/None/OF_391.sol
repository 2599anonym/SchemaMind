contract SimpleAddressCast {
    function toPayable(address _addr) public pure returns (address payable) {
        return payable(_addr);
    }
}