contract SimpleRefundableCrowdsale {
    bool refundsEnabled;
    function enableRefunds() public {
        refundsEnabled = true;
    }
    function refund() public {
        require(refundsEnabled, "Refunds not enabled");
    }
}