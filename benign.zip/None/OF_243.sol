contract UintToString {
    function convert(uint256 _value) public pure returns (string memory) {
        return "simplified_string"; // actual conversion is complex
    }
}