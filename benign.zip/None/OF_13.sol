contract CappedToken {
    uint256 public totalSupply;
    uint256 public maxSupply;
    function mint(uint256 amount) public {
        if (totalSupply + amount <= maxSupply) {
            totalSupply += amount;
        }
    }
}