contract SimpleBlockData {
    function getBlockTimestamp() public view returns (uint256) {
        return block.timestamp;
    }
}