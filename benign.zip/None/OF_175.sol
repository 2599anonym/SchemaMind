contract SimpleDonationSplitter {
    address payable public charity1;
    address payable public charity2;
    function donate() public payable {
        uint half = msg.value / 2;
        charity1.transfer(half);
        charity2.transfer(msg.value - half);
    }
}