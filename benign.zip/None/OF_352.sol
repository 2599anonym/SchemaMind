contract FixedPointMath {
    uint256 constant ONE = 10**18;
    function multiply(uint256 x, uint256 y) public pure returns (uint256) {
        return (x * y) / ONE;
    }
}