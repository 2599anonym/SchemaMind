contract SimpleDonationCollector {
    address payable public beneficiary;
    function collect() public {
        beneficiary.transfer(address(this).balance);
    }
}