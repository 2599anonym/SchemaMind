contract SimpleOwnableV2 {
    address private _owner;
    function transferOwnership(address newOwner) public {
        require(msg.sender == _owner, "Not owner");
        _owner = newOwner;
    }
}