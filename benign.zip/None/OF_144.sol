contract SimpleFundManager {
    address payable public beneficiary;
    function releaseFunds() public {
        beneficiary.transfer(address(this).balance);
    }
}