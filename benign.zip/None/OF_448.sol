contract SimpleTokenInterfaceWithEvents {
    event Transfer(address indexed from, address indexed to, uint256 value);
    function transfer(address to, uint256 value) external returns (bool);
}