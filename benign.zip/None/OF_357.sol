contract SimpleVesting {
    uint public vestingEnd;
    function withdraw() public {
        require(block.timestamp >= vestingEnd);
    }
}