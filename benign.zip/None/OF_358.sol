contract ImmutableData {
    uint256 public immutable creationBlock;
    address public immutable creator;
    constructor() {
        creationBlock = block.number;
        creator = msg.sender;
    }
}