contract SimpleBatchTransfer {
    IERC20 public token;
    function batchTransfer(address[] memory recipients, uint amount) public {
        for (uint i = 0; i < recipients.length; i++) {
            token.transfer(recipients[i], amount);
        }
    }
}