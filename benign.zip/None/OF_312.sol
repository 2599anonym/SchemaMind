contract SimpleLogger {
    event Log(string message);
    function createLog(string memory message) public {
        emit Log(message);
    }
}