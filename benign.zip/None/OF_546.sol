contract SimpleTokenVaultV2 {
    mapping(IERC20 => mapping(address => uint256)) public userBalances;
    function deposit(IERC20 token, uint256 amount) public {
        token.transferFrom(msg.sender, address(this), amount);
        userBalances[token][msg.sender] += amount;
    }
}