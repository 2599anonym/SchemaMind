contract SimpleAllowanceManager {
    mapping(address => uint) public allowances;
    function decreaseAllowance(uint amount) public {
        uint currentAllowance = allowances[msg.sender];
        require(currentAllowance >= amount, "Amount exceeds allowance");
        allowances[msg.sender] = currentAllowance - amount;
    }
}