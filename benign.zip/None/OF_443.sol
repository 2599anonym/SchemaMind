contract SimpleVirtualOverride {
    event Logged(string msg);
    function log() public virtual {
        emit Logged("Base");
    }
}

contract Derived is SimpleVirtualOverride {
    function log() public override {
        emit Logged("Derived");
    }
}