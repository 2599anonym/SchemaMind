contract SimpleHashComparator {
    function compareHashes(bytes32 h1, bytes32 h2) public pure returns (bool) {
        return h1 == h2;
    }
}