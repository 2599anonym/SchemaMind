contract SimpleTimeCheckV2 {
    uint public constant START_TIME = 1704067200; // 2024-01-01
    function checkTime() public view returns(bool) {
        return block.timestamp > START_TIME;
    }
}