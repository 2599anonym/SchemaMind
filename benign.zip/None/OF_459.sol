contract UUPSProxy {
    address public implementation;
    function _setImplementation(address newImplementation) internal {
        implementation = newImplementation;
    }
}