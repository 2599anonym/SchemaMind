contract SimpleCodeSizeChecker {
    function getCodeSize(address addr) public view returns (uint) {
        return addr.code.length;
    }
}