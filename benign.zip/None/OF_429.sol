contract SimpleViewModifier {
    modifier checkSomething() {
        require(true); // some check
        _;
    }
    function getValue() public view checkSomething returns (uint) {
        return 42;
    }
}