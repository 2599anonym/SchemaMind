contract SimpleNFTTransferFrom {
    // IERC721 public nft;
    function transferMyNFT(address from, address to, uint256 tokenId) public {
        // nft.safeTransferFrom(from, to, tokenId);
    }
}