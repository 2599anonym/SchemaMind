contract SimpleTokenSwapper {
    IERC20 public tokenA;
    IERC20 public tokenB;
    function swap(uint amountA) public {
        tokenA.transferFrom(msg.sender, address(this), amountA);
        // calculate amountB and transfer
    }
}