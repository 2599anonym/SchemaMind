contract SimpleIfElse {
    function checkValue(uint v) public pure returns (string memory) {
        if (v < 10) {
            return "Small";
        } else if (v < 100) {
            return "Medium";
        } else {
            return "Large";
        }
    }
}