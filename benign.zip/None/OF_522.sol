contract SimpleConditionalReturnV2 {
    function isPositive(int256 value) public pure returns (bool) {
        return value > 0;
    }
}