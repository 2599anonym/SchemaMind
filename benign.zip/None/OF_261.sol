contract SimpleProxyReader {
    address public implementation;
    function getImplementation() public view returns (address) {
        return implementation;
    }
}