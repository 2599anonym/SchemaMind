contract SimplePausableV2 {
    address public pauser;
    bool public isPaused;
    function setPaused(bool _paused) public {
        require(msg.sender == pauser, "Not pauser");
        isPaused = _paused;
    }
}