contract SimpleStruct {
    struct User {
        uint id;
        string name;
    }
    mapping(address => User) public users;
    function setUser(uint id, string memory name) public {
        users[msg.sender] = User(id, name);
    }
}