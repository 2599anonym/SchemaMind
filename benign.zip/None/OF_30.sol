contract SimpleAuctioneer {
    uint256 public highestBid;
    address public highestBidder;
    function bid() public payable {
        require(msg.value > highestBid, "Bid not high enough");
        highestBid = msg.value;
        highestBidder = msg.sender;
    }
}