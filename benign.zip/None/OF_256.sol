contract SimpleAddressArray {
    address[] public userAddresses;
    function addUser() public {
        userAddresses.push(msg.sender);
    }
}