contract SimpleSubscription {
    mapping(address => uint) public expiry;
    function subscribe(uint duration) public {
        expiry[msg.sender] = block.timestamp + duration;
    }
}