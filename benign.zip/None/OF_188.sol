contract SimpleRoundManager {
    uint public currentRound;
    function advanceRound() public {
        currentRound++;
    }
}