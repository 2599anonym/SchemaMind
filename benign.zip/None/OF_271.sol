contract SimplePercentageCalculator {
    function calculate(uint256 amount, uint256 bps) public pure returns (uint256) {
        require(bps <= 10000, "BPS too high");
        return (amount * bps) / 10000;
    }
}