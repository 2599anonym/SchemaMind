contract EIP712Domain {
    bytes32 public DOMAIN_SEPARATOR;
    constructor() {
        // set domain separator
    }
}