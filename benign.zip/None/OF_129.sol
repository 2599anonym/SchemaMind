contract SimpleAddressWhitelist {
    mapping(address => bool) public whitelist;
    function add(address _addr) public {
        whitelist[_addr] = true;
    }
}