contract SimpleStringArray {
    string[] public values;
    function addValue(string memory _value) public {
        values.push(_value);
    }
}