contract SimpleAddressPair {
    address public address1;
    address public address2;
    function setPair(address _addr1, address _addr2) public {
        address1 = _addr1;
        address2 = _addr2;
    }
}