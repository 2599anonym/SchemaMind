contract SimpleStringRegistry {
    mapping(uint => string) public names;
    function registerName(uint id, string memory name) public {
        names[id] = name;
    }
}