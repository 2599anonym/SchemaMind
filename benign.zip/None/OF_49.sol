contract SimpleCheck {
    function isEven(uint256 n) public pure returns (bool) {
        return n % 2 == 0;
    }
}