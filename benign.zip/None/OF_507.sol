contract SimpleBalanceReaderV2 {
    IERC20 public token;
    function read(address user) public view returns (uint256) {
        return token.balanceOf(user);
    }
}