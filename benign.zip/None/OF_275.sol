contract SimpleContractLockerV2 {
    address public locker;
    bool public isLocked;
    function setLock(bool _locked) public {
        if(msg.sender == locker) {
            isLocked = _locked;
        }
    }
}