contract SimpleTimestampLogger {
    mapping(address => uint) public logs;
    function log() public {
        logs[msg.sender] = block.timestamp;
    }
}