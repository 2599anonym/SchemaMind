contract SimpleDataHash {
    bytes32 public dataHash;
    function setData(string memory _data) public {
        dataHash = keccak256(abi.encodePacked(_data));
    }
}