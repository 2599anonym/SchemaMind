contract AccessControl {
    mapping(bytes32 => mapping(address => bool)) public roles;
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
    function hasRole(bytes32 role, address account) public view returns (bool) {
        return roles[role][account];
    }
}