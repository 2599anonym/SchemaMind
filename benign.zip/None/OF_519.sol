contract SimpleAllowanceManagerV3 {
    mapping(address => uint256) public limits;
    function setLimit(uint256 limit) public {
        limits[msg.sender] = limit;
    }
}