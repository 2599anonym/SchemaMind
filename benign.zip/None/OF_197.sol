contract SimplePriceComparator {
    int public priceA;
    int public priceB;
    function isPriceAGreater() public view returns (bool) {
        return priceA > priceB;
    }
}