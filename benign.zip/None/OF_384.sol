contract SimpleMemoryStruct {
    struct Point { uint x; uint y; }
    function processPoint() public {
        Point memory p = Point(1, 2);
        p.x = p.x + 1;
    }
}