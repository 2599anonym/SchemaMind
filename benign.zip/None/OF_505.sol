contract SimpleTokenLockerV2 {
    IERC20 public token;
    bool public isLocked;

    function lockTokens() public {
        // requires specific role
        isLocked = true;
    }
}