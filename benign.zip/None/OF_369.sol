contract SimpleMessageSender {
    function whoAmI() public view returns (address) {
        return msg.sender;
    }
}