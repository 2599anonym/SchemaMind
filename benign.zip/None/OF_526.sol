contract SimpleTokenRetrieverV3 {
    function rescueTokens(IERC20 tkn, address to) public {
        uint256 bal = tkn.balanceOf(address(this));
        tkn.transfer(to, bal);
    }
}