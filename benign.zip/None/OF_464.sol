contract SimpleCounterLib {
    struct Counter {
        uint256 _value;
    }
    function increment(Counter storage counter) internal {
        counter._value++;
    }
}