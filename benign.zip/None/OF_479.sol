contract MinimumContribution {
    uint public constant MIN_CONTRIBUTION = 0.1 ether;
    function contribute() public payable {
        require(msg.value >= MIN_CONTRIBUTION);
    }
}