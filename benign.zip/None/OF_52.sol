contract SimpleNFTMint {
    mapping(uint256 => address) _owners;
    uint256 private _tokenIdCounter;
    function mint(address to) public {
        _tokenIdCounter++;
        _owners[_tokenIdCounter] = to;
    }
}