contract SimpleWeightedAverage {
    function calculate(uint valA, uint weightA, uint valB, uint weightB) public pure returns (uint) {
        uint totalWeight = weightA + weightB;
        require(totalWeight > 0, "Total weight is zero");
        return (valA * weightA + valB * weightB) / totalWeight;
    }
}