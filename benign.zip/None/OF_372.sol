contract SimpleViewFunction {
    uint public myValue = 10;
    function viewValue() public view returns (uint) {
        return myValue;
    }
}