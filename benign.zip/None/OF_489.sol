contract SimpleFeeSwitch {
    bool public feesEnabled;
    function toggleFees() public {
        feesEnabled = !feesEnabled;
    }
}