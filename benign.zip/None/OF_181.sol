contract SimpleFeeCharger {
    uint public constant FEE = 0.001 ether;
    function chargeFee() public {
        // logic to transfer FEE from msg.sender
    }
}