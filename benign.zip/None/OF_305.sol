contract SimpleNFTApprovalForAll {
    mapping(address => mapping(address => bool)) public isApprovedForAll;
    function setApprovalForAll(address operator, bool approved) public {
        isApprovedForAll[msg.sender][operator] = approved;
    }
}