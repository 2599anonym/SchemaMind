contract SimpleAllowanceManagerV2 {
    mapping(address => uint256) public allowances;
    function set(uint256 amount) public {
        allowances[msg.sender] = amount;
    }
}