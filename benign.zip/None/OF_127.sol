contract SimpleTokenBurner {
    IERC20 public token;
    function burnMyTokens(uint256 amount) public {
        token.transferFrom(msg.sender, address(0), amount); // Simplified burn
    }
}