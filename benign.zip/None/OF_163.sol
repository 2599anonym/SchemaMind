contract SimpleLockableToken {
    bool public locked;
    function transfer() public {
        require(!locked, "Tokens are locked");
    }
}