contract SimpleBurn {
    mapping(address => uint256) public balances;
    function burn(uint256 amount) public {
        uint256 balance = balances[msg.sender];
        if (amount <= balance) {
            balances[msg.sender] = balance - amount;
        }
    }
}