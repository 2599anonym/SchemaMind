contract SimpleContractStateV2 {
    bool public isFrozen;
    function freeze() public {
        isFrozen = true;
    }
}