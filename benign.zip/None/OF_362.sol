contract SimpleArraySum {
    function sum(uint256[] memory _data) public pure returns (uint256) {
        uint256 total = 0;
        for (uint i = 0; i < _data.length; i++) {
            total += _data[i];
            require(total >= _data[i]);
        }
        return total;
    }
}