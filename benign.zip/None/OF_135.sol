contract StagedVesting {
    uint256[] public stages;
    uint256 public startDate;
    function getCurrentStage() public view returns (uint) {
        uint elapsedTime = block.timestamp - startDate;
        uint stageDuration = 30 days;
        return elapsedTime / stageDuration;
    }
}