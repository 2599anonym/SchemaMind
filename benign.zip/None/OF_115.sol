contract SimpleVestingWallet {
    uint64 public immutable releaseTime;
    constructor(uint64 _releaseTime) {
        releaseTime = _releaseTime;
    }
}