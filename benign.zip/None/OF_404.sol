contract SimpleArrayMemory {
    function createArray(uint size) public pure returns (uint[] memory) {
        uint[] memory newArr = new uint[](size);
        return newArr;
    }
}