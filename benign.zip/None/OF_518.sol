contract SimpleDataStoreV3 {
    mapping(address => uint256) public userValues;
    function setMyValue(uint256 value) public {
        userValues[msg.sender] = value;
    }
}