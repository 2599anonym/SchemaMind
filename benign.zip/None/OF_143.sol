contract SimpleApprovalQueue {
    address[] public queue;
    function addToQueue(address _addr) public {
        queue.push(_addr);
    }
}