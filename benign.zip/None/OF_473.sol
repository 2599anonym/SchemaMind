contract SimpleBlockProvider {
    function getBlockNumber() public view returns (uint256) {
        return block.number;
    }
}