contract SimpleNFTCounter {
    mapping(address => uint256) public balanceOf;
    function _incrementBalance(address user) private {
        balanceOf[user]++;
    }
}