contract Versioned {
    uint256 public version;
    function incrementVersion() public {
        version = version + 1;
    }
}