contract SimpleDataPublisher {
    bytes public publishedData;
    function publish(bytes memory _data) public {
        publishedData = _data;
    }
}