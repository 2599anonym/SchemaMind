contract SimpleKYCV2 {
    enum KYCStatus { None, Pending, Approved }
    mapping(address => KYCStatus) public kyc;

    function approveKYC(address user) public {
        // access control
        kyc[user] = KYCStatus.Approved;
    }
}