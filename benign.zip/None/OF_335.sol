contract TimeBound {
    uint public creationTime;
    constructor() public {
        creationTime = block.timestamp;
    }
}