contract SimpleStatusContractV2 {
    mapping(uint256 => string) public statuses;
    function setStatus(uint256 id, string memory status) public {
        statuses[id] = status;
    }
}