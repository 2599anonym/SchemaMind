contract TieredAccess {
    mapping(address => uint8) public accessLevel;
    function grantAccess(address user, uint8 level) public {
        // requires check for caller's access level
        accessLevel[user] = level;
    }
}