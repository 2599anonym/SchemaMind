contract SimpleVotingWithDeadline {
    uint public votingEnds;
    function vote() public {
        require(block.timestamp < votingEnds, "Voting has ended");
    }
}