contract ContractAddressHolder {
    address public myContractAddress;
    constructor() {
        myContractAddress = address(this);
    }
}