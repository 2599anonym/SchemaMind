contract SimpleTokenRetrieverV2 {
    function recoverTokens(IERC20 token, address to) public {
        uint256 balance = token.balanceOf(address(this));
        token.transfer(to, balance);
    }
}