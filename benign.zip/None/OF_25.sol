contract SimpleCondition {
    bool public condition;
    function setCondition(bool _condition) public {
        condition = _condition;
    }
}