contract SimpleOracleConsumer {
    IOracle public oracle;
    function getPrice(string memory symbol) public view returns (uint256) {
        return oracle.getPrice(symbol);
    }
}