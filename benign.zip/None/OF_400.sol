contract SimpleBreakContinue {
    function processArray(uint[] memory data) public pure returns (uint) {
        uint total = 0;
        for (uint i=0; i < data.length; i++) {
            if (data[i] == 0) continue;
            if (total > 1000) break;
            total += data[i];
        }
        return total;
    }
}