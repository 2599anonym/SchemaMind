contract SimpleCommitReveal {
    mapping(address => bytes32) public commits;
    function commit(bytes32 hash) public {
        commits[msg.sender] = hash;
    }
    function reveal(uint256 nonce, address user) public {
        require(keccak256(abi.encodePacked(nonce)) == commits[user]);
        // reveal logic
    }
}