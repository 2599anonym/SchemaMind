contract SimpleLibraryUser {
    // using SimpleMathLib for uint256;
    function useLib(uint256 a, uint256 b) public pure returns (uint256) {
        // return a.add(b);
    }
}