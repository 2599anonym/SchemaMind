contract SimplePayable {
    event Paid(address user, uint amount);
    function pay() public payable {
        require(msg.value > 0, "Payment must be positive");
        emit Paid(msg.sender, msg.value);
    }
}