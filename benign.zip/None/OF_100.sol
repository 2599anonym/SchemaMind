contract SimpleKYC {
    mapping(address => bool) public kycStatus;
    function setKycCompleted(address user) public {
        kycStatus[user] = true;
    }
}