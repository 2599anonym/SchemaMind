contract SimpleErrorThrower {
    function throwError() public pure {
        revert("This is a test error");
    }
}