contract SimpleTimeWeightedData {
    uint public lastUpdateTime;
    uint public value;
    function update(uint newValue) public {
        // weighted average calculation based on time
        lastUpdateTime = block.timestamp;
        value = newValue;
    }
}