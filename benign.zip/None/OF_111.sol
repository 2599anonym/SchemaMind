contract SimpleBurnerRole {
    mapping(address => bool) public isBurner;
    function addBurner(address _burner) public {
        // access control
        isBurner[_burner] = true;
    }
}