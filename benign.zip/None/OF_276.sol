contract SimpleEventNotifier {
    event Notification(address indexed user, string message);
    function notify(string memory _message) public {
        emit Notification(msg.sender, _message);
    }
}