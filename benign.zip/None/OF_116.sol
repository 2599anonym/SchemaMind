contract SimpleConditionalLogic {
    function getValue(bool condition) public pure returns (uint) {
        if (condition) {
            return 1;
        } else {
            return 0;
        }
    }
}