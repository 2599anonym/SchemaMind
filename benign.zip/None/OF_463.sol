contract SimpleGovernor {
    enum ProposalState { Pending, Active, Succeeded, Defeated }
    struct Proposal {
        ProposalState state;
    }
    mapping(uint256 => Proposal) public proposals;
}