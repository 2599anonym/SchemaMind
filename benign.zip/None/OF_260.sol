contract SimpleDeadlineManager {
    uint256 public immutable deadline;
    constructor(uint256 _duration) {
        deadline = block.timestamp + _duration;
    }
}