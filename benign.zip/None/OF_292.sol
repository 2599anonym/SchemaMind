contract SimpleContractStateReader {
    enum Status { Created, Active, Inactive }
    Status public status;
    function getStatus() public view returns (Status) {
        return status;
    }
}