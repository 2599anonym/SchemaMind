contract SimpleAllowanceApprover {
    IERC20 public token;
    address public spender;
    function approveSpender(uint amount) public {
        token.approve(spender, amount);
    }
}