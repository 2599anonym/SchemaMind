contract SimpleAbstractContract {
    // An abstract contract has at least one function without an implementation.
    function doAction() external virtual;
}