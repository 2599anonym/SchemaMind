contract VariableRateSale {
    function getRate() public view returns (uint) {
        if (block.timestamp < 1675209600) { // Before Feb 2023
            return 1200;
        }
        return 1000;
    }
}