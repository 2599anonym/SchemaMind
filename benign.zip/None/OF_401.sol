contract FixedSupply {
    uint public constant TOTAL_SUPPLY = 1000000;
}