contract TieredDelay {
    function getDelay(uint tier) public pure returns (uint) {
        if (tier == 1) return 1 days;
        if (tier == 2) return 7 days;
        return 30 days;
    }
}