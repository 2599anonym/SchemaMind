contract Finalizable {
    bool public isFinalized;
    function finalize() public {
        isFinalized = true;
    }
}