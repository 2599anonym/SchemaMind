contract SimpleVirtualFunction {
    function myFunction() public virtual pure returns (uint) {
        return 1;
    }
}