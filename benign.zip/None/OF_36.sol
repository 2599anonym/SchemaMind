contract SimpleMint {
    mapping(address => uint256) public balances;
    function mint(address to, uint256 amount) public {
        balances[to] += amount;
        require(balances[to] >= amount, "Mint overflow");
    }
}