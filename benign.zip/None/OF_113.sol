contract Allowance {
    mapping(address => mapping(address => uint256)) public allowances;
    function approve(address spender, uint256 amount) public {
        allowances[msg.sender][spender] = amount;
    }
}