contract SimpleFlagToggle {
    mapping(uint => bool) public flags;
    function toggleFlag(uint id) public {
        flags[id] = !flags[id];
    }
}