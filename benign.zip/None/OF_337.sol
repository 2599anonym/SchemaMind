contract LimitedFunctionality {
    bool public isEnabled;
    modifier onlyWhenEnabled() {
        require(isEnabled, "Functionality is disabled");
        _;
    }

    function doSomething() public onlyWhenEnabled {
        // sensitive logic
    }
}