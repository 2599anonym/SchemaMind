contract DataFeedProxy {
    address public feedAddress;
    function latestRoundData() public view returns (uint80, int256, uint256, uint256, uint80) {
        // IAggregatorV3(feedAddress).latestRoundData();
    }
}