contract SimpleAddressRegistryV2 {
    mapping(string => address) public registry;
    function registerAddress(string memory name, address addr) public {
        registry[name] = addr;
    }
}