contract SimpleDonationWithGoal {
    uint256 public goal;
    uint256 public raised;
    function hasMetGoal() public view returns (bool) {
        return raised >= goal;
    }
}