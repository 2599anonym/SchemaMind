contract SimpleEventTriggerV2 {
    event ActionTriggered(address indexed user, uint256 value);
    function trigger(uint256 value) public {
        emit ActionTriggered(msg.sender, value);
    }
}