contract SimplePriceOracle {
    uint public price;
    function setPrice(uint _price) public {
        price = _price;
    }
}