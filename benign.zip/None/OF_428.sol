contract SimpleArrayOfStructs {
    struct Item {
        uint id;
        uint price;
    }
    Item[] public items;
    function addItem(uint id, uint price) public {
        items.push(Item(id, price));
    }
}