contract SimpleDataAnchorV3 {
    mapping(bytes32 => bool) public dataAnchored;
    function anchorData(string memory data) public {
        dataAnchored[keccak256(abi.encodePacked(data))] = true;
    }
}