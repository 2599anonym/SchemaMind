contract SimpleAddressCache {
    address private cachedAddress;
    function setCache(address _addr) public {
        cachedAddress = _addr;
    }
}