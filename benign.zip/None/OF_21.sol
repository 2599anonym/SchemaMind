contract AllowanceManager {
    mapping(address => uint256) public allowance;
    function increaseAllowance(uint256 addedValue) public {
        uint256 newAllowance = allowance[msg.sender] + addedValue;
        require(newAllowance >= allowance[msg.sender]);
        allowance[msg.sender] = newAllowance;
    }
}