contract SimpleBurnableTokenV2 {
    mapping(address => uint256) public balances;
    function burn(uint256 amount) public {
        uint256 balance = balances[msg.sender];
        require(amount <= balance, "Amount exceeds balance");
        balances[msg.sender] = balance - amount;
    }
}