contract SimpleStatefulV2 {
    uint8 public status;
    function setStatus(uint8 _status) public {
        require(_status < 3, "Invalid status"); // 0, 1, 2
        status = _status;
    }
}