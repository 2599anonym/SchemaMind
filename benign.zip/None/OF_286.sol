contract SimpleNFTEnumerable {
    uint256[] public allTokens;
    function _addTokenToAllTokensEnumeration(uint256 tokenId) private {
        allTokens.push(tokenId);
    }
}