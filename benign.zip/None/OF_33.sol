contract SimpleCounter {
    uint8 public counter;
    function increment() public {
        if (counter < 255) {
            counter++;
        }
    }
}