contract SimpleBounty {
    uint public reward;
    bool public claimed;
    function claim() public {
        require(!claimed, "Bounty already claimed");
        claimed = true;
        // transfer reward
    }
}