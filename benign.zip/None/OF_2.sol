contract SimpleAccessControl {
    address public admin;
    modifier onlyAdmin() {
        require(msg.sender == admin);
        _;
    }
    function changeAdmin(address newAdmin) public onlyAdmin {
        admin = newAdmin;
    }
}