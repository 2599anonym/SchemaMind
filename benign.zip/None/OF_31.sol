contract SimpleWhitelist {
    mapping(address => bool) private whitelist;
    function isWhitelisted(address _addr) public view returns(bool) {
        return whitelist[_addr];
    }
}