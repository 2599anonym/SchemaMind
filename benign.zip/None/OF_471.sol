contract SimpleSignatureChecker {
    function isValidSignature(bytes32 hash, bytes memory signature) internal view returns (bool) {
        // ecrecover logic
        return true;
    }
}