contract NFTEnumerable {
    mapping(address => uint256[]) public ownedTokens;
    function _addTokenToOwnerEnumeration(address to, uint256 tokenId) private {
        ownedTokens[to].push(tokenId);
    }
}