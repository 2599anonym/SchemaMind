contract SimpleMemoryPointer {
    function process(uint[] memory data) public pure {
        uint[] memory p = data;
        p[0] = 123; // This modifies the 'data' array in memory
    }
}