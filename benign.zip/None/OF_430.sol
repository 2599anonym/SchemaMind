contract SimplePayableModifier {
    modifier costs(uint amount) {
        require(msg.value >= amount, "Insufficient payment");
        _;
    }
    function specialAction() public payable costs(1 ether) {
        // logic
    }
}