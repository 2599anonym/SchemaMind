contract TokenGated {
    IERC20 public token;
    uint256 public requiredBalance = 100;
    function accessFeature() public {
        require(token.balanceOf(msg.sender) >= requiredBalance);
        // feature logic
    }
}