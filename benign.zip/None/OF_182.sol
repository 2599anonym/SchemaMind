contract SimpleThresholdCheck {
    uint public constant THRESHOLD = 1000;
    function isAboveThreshold(uint value) public pure returns (bool) {
        return value > THRESHOLD;
    }
}