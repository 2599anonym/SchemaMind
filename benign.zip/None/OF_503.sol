contract SimpleLinearVestingV2 {
    uint256 public vestedAmount;
    uint256 public startTime;
    uint256 public rate; // amount per second

    function calculateVested() public view returns (uint256) {
        if (block.timestamp <= startTime) return 0;
        return (block.timestamp - startTime) * rate;
    }
}