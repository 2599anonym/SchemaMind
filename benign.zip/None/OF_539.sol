contract SimpleRefundableCrowdsaleV2 {
    enum State { Active, GoalReached, Refunding }
    State public currentState;
    function setState(State _state) public {
        currentState = _state;
    }
}