contract BalanceThreshold {
    uint256 public constant MINIMUM_BALANCE = 100 ether;
    function checkMinimum(address user) public view returns (bool) {
        return user.balance >= MINIMUM_BALANCE;
    }
}