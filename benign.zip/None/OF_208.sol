contract SimpleTwoStepTransfer {
    address public pendingOwner;
    function transferOwnership(address newOwner) public {
        // owner check
        pendingOwner = newOwner;
    }
    function acceptOwnership() public {
        require(msg.sender == pendingOwner, "Not pending owner");
        // set new owner
    }
}