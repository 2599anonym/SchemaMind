contract SimpleEscrowV2 {
    enum State { AwaitingPayment, AwaitingDelivery, Complete }
    State public currentState;
    function updateState(State newState) public {
        currentState = newState;
    }
}