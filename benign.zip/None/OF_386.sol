contract SimpleGetter {
    uint256 public value;
    // The public keyword creates a getter function automatically
}