contract SimpleValueComparator {
    function isGreater(uint256 a, uint256 b) public pure returns (bool) {
        return a > b;
    }
}