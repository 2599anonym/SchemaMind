contract SimpleMathV4 {
    function multiplyByTwo(uint256 val) public pure returns (uint256) {
        uint256 result = val * 2;
        require(result / 2 == val, "Overflow");
        return result;
    }
}