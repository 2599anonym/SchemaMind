contract SimpleEventTrigger {
    event Triggered(uint timestamp);
    function trigger() public {
        emit Triggered(block.timestamp);
    }
}