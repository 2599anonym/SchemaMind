contract TimeLock {
    uint256 public releaseTime;
    function release() public {
        require(block.timestamp >= releaseTime, "Cannot release yet.");
    }
}