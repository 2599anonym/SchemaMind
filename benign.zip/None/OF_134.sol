contract SimpleDistributorWithFee {
    uint fee;
    function distribute() public payable {
        uint amount = msg.value;
        uint feeAmount = (amount * fee) / 100;
        // transfer (amount - feeAmount)
    }
}