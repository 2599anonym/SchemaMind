contract SimpleNFTApproval {
    mapping(uint256 => address) public approved;
    function approve(address to, uint256 tokenId) public {
        // requires ownership check
        approved[tokenId] = to;
    }
}