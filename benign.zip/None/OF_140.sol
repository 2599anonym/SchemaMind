contract SimpleTokenVault {
    IERC20 public token;
    mapping(address => uint) public deposits;
    function depositTokens(uint amount) public {
        token.transferFrom(msg.sender, address(this), amount);
        deposits[msg.sender] += amount;
    }
}