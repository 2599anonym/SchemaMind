contract SimpleFeatureFlag {
    mapping(string => bool) public features;
    function enableFeature(string memory featureName) public {
        features[featureName] = true;
    }
}