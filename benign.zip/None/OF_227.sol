contract MinimumValue {
    uint256 public minValue = 100;
    function updateValue(uint256 _newValue) public {
        require(_newValue >= minValue, "Value is too low");
    }
}