contract SimpleAddressLogger {
    address[] public loggedAddresses;
    function logAddress() public {
        loggedAddresses.push(msg.sender);
    }
}