contract SimpleSelfDestruct {
    function close(address payable recipient) public {
        // owner check
        selfdestruct(recipient);
    }
}