contract Checkpoint {
    mapping(uint => uint) public checkpoints;
    function saveCheckpoint(uint value) public {
        checkpoints[block.number] = value;
    }
}