contract SimpleRefundMechanism {
    mapping(address => uint256) public contributions;
    function refundContribution() public {
        uint256 amount = contributions[msg.sender];
        require(amount > 0, "No contribution to refund");
        contributions[msg.sender] = 0;
        payable(msg.sender).transfer(amount);
    }
}