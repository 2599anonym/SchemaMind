contract SimpleTwoFactor {
    mapping(address => bool) public firstFactor;
    function confirmFirstFactor() public {
        firstFactor[msg.sender] = true;
    }
    function executeTwoFactor() public {
        require(firstFactor[msg.sender], "First factor not confirmed");
    }
}