contract SimpleContractState {
    bool public isActive;
    constructor(bool _isActive) {
        isActive = _isActive;
    }
}