contract SimpleNFTEnumerableV2 {
    address[] public allOwners;
    function _addOwner(address owner) private {
        allOwners.push(owner);
    }
}