contract SimpleNFTTransfer {
    mapping(uint256 => address) public owners;
    function transfer(address _to, uint256 _tokenId) public {
        require(owners[_tokenId] == msg.sender, "Not the owner");
        owners[_tokenId] = _to;
    }
}