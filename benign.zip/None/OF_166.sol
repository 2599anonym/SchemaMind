contract SimpleQuorum {
    uint public votes;
    uint public constant REQUIRED_VOTES = 5;
    function hasQuorum() public view returns (bool) {
        return votes >= REQUIRED_VOTES;
    }
}