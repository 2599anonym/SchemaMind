contract SimpleCounterV2 {
    uint256 public count;
    function increment(uint256 amount) public {
        count = count + amount;
        require(count >= amount, "Counter overflow");
    }
}