contract SimpleMulticall {
    function multicall(bytes[] memory data) public returns (bytes[] memory results) {
        results = new bytes[](data.length);
        for (uint i = 0; i < data.length; i++) {
            (bool success, bytes memory res) = address(this).delegatecall(data[i]);
            require(success);
            results[i] = res;
        }
    }
}