contract BasicOracle {
    mapping(address => bool) public isDataProvider;
    int256 public value;
    function updateValue(int256 _newValue) public {
        require(isDataProvider[msg.sender], "Not a data provider");
        value = _newValue;
    }
}