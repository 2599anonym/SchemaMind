contract Pausable {
    bool public isPaused;
    function pause() public {
        isPaused = true;
    }
    function unpause() public {
        isPaused = false;
    }
}