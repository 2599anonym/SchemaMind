contract Percentage {
    function calculatePercentage(uint amount, uint bps) public pure returns (uint) {
        return (amount * bps) / 10000;
    }
}