contract SimpleVoter {
    mapping(address => bool) private hasVoted;
    function vote() public {
        require(hasVoted[msg.sender] == false, "Already voted");
        hasVoted[msg.sender] = true;
    }
}