contract SimpleNFTBurn {
    mapping(uint256 => address) _owners;
    function burn(uint256 tokenId) public {
        require(_owners[tokenId] == msg.sender, "Not owner");
        _owners[tokenId] = address(0);
    }
}