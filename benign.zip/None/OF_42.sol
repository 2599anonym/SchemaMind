contract SimpleApproval {
    mapping(address => bool) public approvedSenders;
    function approve(address sender) public {
        approvedSenders[sender] = true;
    }
}