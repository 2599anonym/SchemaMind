contract SimpleCounterWithMaxV2 {
    uint256 public count;
    uint256 public maxCount;
    function increment() public {
        require(count < maxCount, "Max count reached");
        count++;
    }
}