contract SimpleBalanceCheck {
    function getMyBalance() public view returns (uint) {
        return msg.sender.balance;
    }
}