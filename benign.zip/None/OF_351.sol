contract SimpleStateful {
    uint public counter;
    string public status;
    function update(uint _counter, string memory _status) public {
        counter = _counter;
        status = _status;
    }
}