contract Crowdsale {
    uint256 public endTime;
    function hasConcluded() public view returns (bool) {
        return block.timestamp >= endTime;
    }
}