contract SimpleRateProvider {
    uint public rate = 100;
    function getRate() public view returns (uint) {
        return rate;
    }
}