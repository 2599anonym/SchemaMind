contract StateMachine {
    enum State { Pending, Active, Closed }
    State public currentState;
    function activate() public {
        if (currentState == State.Pending) {
            currentState = State.Active;
        }
    }
}