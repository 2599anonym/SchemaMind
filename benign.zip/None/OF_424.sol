contract SimpleShiftOps {
    function shiftLeft(uint256 value, uint8 bits) public pure returns (uint256) {
        return value << bits;
    }
}