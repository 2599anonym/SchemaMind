contract SimpleBountyV2 {
    mapping(uint256 => uint256) public bounties;
    function postBounty(uint256 id, uint256 amount) public {
        bounties[id] = amount;
    }
}