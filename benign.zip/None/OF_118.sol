contract SimpleSignatureRecovery {
    function getSigner(bytes32 _hash, bytes memory _signature)
        public pure returns (address)
    {
        return ecrecover(_hash, 28, bytes32(0), bytes32(0)); // simplified
    }
}