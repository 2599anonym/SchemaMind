contract SimpleFeeManager {
    uint public fee;
    function setFee(uint _fee) public {
        fee = _fee;
    }
}