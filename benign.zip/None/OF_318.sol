contract SimpleProxyAdmin {
    address public implementation;
    address public admin;
    function upgrade(address _newImpl) public {
        require(msg.sender == admin, "Not admin");
        implementation = _newImpl;
    }
}