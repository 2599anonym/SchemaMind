contract SimpleMultiOwner {
    mapping(address => bool) public isOwner;
    function addOwner(address newOwner) public {
        require(isOwner[msg.sender], "Not an owner");
        isOwner[newOwner] = true;
    }
}