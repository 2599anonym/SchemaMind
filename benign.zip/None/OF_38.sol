contract SimpleTimeCheck {
    uint256 public startTime = 1640995200; // 2022-01-01
    function hasStarted() public view returns (bool) {
        return block.timestamp >= startTime;
    }
}