contract SimpleThresholdGate {
    uint256 public value;
    uint256 public constant THRESHOLD = 500;
    function passGate() public view returns (bool) {
        return value >= THRESHOLD;
    }
}