contract SimpleDataFeedConsumer {
    IDataFeed public feed;
    function readData() public view returns (int) {
        return feed.latestAnswer();
    }
}