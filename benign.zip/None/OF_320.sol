contract SimpleTimeLockManager {
    mapping(uint256 => uint256) public lockEndTimes;
    function setLock(uint256 id, uint256 duration) public {
        lockEndTimes[id] = block.timestamp + duration;
    }
}