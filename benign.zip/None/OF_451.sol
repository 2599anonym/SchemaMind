contract RoleBasedACL {
    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR");
    mapping(bytes32 => mapping(address => bool)) private _roles;
    function grantOperator(address account) public {
        // requires admin
        _roles[OPERATOR_ROLE][account] = true;
    }
}