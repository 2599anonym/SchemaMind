contract SimpleEscrowWithTimelock {
    uint public releaseTime;
    function release() public {
        require(block.timestamp > releaseTime, "Timelock active");
    }
}