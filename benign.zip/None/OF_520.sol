contract SimpleBurnerV2 {
    IERC20 public token;
    function burnMyTokens(uint256 amount) public {
        require(token.balanceOf(msg.sender) >= amount, "Not enough tokens");
        // burn logic
    }
}