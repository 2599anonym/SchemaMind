contract SimpleMerkleDistributor {
    bytes32 public merkleRoot;
    mapping(uint256 => bool) public isClaimed;
    function claim(uint256 index, bytes32[] calldata merkleProof) public {
        require(!isClaimed[index], "Already claimed");
        // verify proof
        isClaimed[index] = true;
    }
}