contract SimpleTieredRate {
    function rate() public view returns (uint) {
        if (block.number < 1000000) return 500;
        return 400;
    }
}