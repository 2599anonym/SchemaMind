contract SimpleNamedReturn {
    function getNamedValue() public pure returns (uint value) {
        value = 42;
    }
}