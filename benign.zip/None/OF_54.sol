contract SimpleTimeVesting {
    uint256 public releaseTime;
    function isReleased() public view returns (bool) {
        return block.timestamp >= releaseTime;
    }
}