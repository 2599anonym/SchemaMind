contract SimpleConstructor {
    address public immutable deployer;
    constructor() {
        deployer = msg.sender;
    }
}