contract RoleBasedAccess {
    mapping(address => bool) public isAdmin;
    function addAdmin(address user) public {
        if (isAdmin[msg.sender]) {
            isAdmin[user] = true;
        }
    }
}