contract SimpleDataVerification {
    bytes32 private expectedHash;
    function verify(string memory data) public view returns (bool) {
        return keccak256(abi.encode(data)) == expectedHash;
    }
}