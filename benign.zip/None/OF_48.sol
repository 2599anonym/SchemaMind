contract SimpleConfig {
    uint256 public param;
    function setParam(uint256 _param) public {
        param = _param;
    }
}