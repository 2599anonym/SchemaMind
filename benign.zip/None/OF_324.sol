contract SimpleAllowanceChecker {
    mapping(address => mapping(address => uint256)) public allowances;
    function checkAllowance(address owner, address spender) public view returns (uint256) {
        return allowances[owner][spender];
    }
}