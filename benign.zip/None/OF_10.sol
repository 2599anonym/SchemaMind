contract SimpleVoting {
    mapping(address => bool) hasVoted;
    uint256 public yesVotes;
    function voteYes() public {
        require(!hasVoted[msg.sender], "Already voted");
        hasVoted[msg.sender] = true;
        yesVotes += 1;
    }
}