contract SimpleValidatorSet {
    mapping(address => bool) public isValidator;
    function addValidator(address _validator) public {
        isValidator[_validator] = true;
    }
}