contract SimpleCalldataPointer {
    function process(uint[] calldata data) external pure returns(uint) {
        uint[] calldata p = data;
        return p.length;
    }
}