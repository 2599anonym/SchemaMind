contract SimpleVersionTracker {
    string public version = "1.0.0";
    function setVersion(string memory _newVersion) public {
        // access control needed
        version = _newVersion;
    }
}