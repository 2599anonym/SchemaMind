contract SimplePayableFunction {
    function deposit() public payable {
        // logic
    }
}