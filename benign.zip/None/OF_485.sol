contract SimpleDataRegistryV2 {
    mapping(address => string) public userNames;
    function registerName(string memory name) public {
        userNames[msg.sender] = name;
    }
}