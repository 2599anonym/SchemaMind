contract SimpleFeeCollector {
    address public feeAddress;
    uint256 public feeBps = 50; // 0.5%
    function collectFee(uint256 amount) internal {
        uint256 fee = (amount * feeBps) / 10000;
        // transfer fee to feeAddress
    }
}