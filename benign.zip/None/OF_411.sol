contract SimpleUnchecked {
    function addUnchecked(uint a, uint b) public pure returns (uint) {
        // Use with extreme caution, only when overflow is impossible
        unchecked { return a + b; }
    }
}