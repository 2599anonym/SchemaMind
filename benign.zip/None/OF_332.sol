contract SimpleTimestampManager {
    uint256 public lastUpdated;
    function updateTimestamp() public {
        lastUpdated = block.timestamp;
    }
}