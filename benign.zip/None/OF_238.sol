contract NFTBurner {
    function burn(uint256 tokenId) public {
        // requires ownership check
        // _burn(tokenId);
    }
}