contract SimpleDataVerificationHash {
    function verifyData(string memory data, bytes32 expectedHash) public pure returns (bool) {
        return keccak256(abi.encodePacked(data)) == expectedHash;
    }
}