contract SimpleAuthenticatorV2 {
    mapping(address => bool) public isAuthorized;
    function checkAuth() public view returns (bool) {
        return isAuthorized[msg.sender];
    }
}