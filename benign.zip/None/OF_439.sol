contract SimpleReturnStruct {
    struct Point { uint x; uint y; }
    function getPoint() public pure returns (Point memory) {
        return Point(1, 2);
    }
}