contract SimpleTimeCheckV3 {
    function isFuture(uint256 time) public view returns (bool) {
        return time > block.timestamp;
    }
}