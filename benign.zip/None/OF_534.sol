contract Lockable {
    bool public isLocked;
    modifier whenNotLocked() {
        require(!isLocked);
        _;
    }
    function performAction() public whenNotLocked {
        // action logic
    }
}