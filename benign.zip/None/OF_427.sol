contract SimpleNestedMapping {
    mapping(address => mapping(uint256 => bool)) public userPermissions;
    function grantPermission(address user, uint256 permissionId) public {
        userPermissions[user][permissionId] = true;
    }
}