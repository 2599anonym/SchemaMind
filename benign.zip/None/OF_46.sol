contract EventManager {
    uint256 public eventDate;
    function isEventOver() public view returns (bool) {
        return block.timestamp > eventDate;
    }
}