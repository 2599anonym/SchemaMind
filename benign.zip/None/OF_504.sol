contract SimpleAccessControlV2 {
    address public admin;
    function changeAdmin(address newAdmin) public {
        require(msg.sender == admin, "Not admin");
        admin = newAdmin;
    }
}