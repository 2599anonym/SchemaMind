contract SimpleDataAnchorV2 {
    mapping(bytes32 => uint256) public dataTimestamps;
    function anchor() public {
        bytes32 data = keccak256(abi.encodePacked(msg.sender, block.number));
        dataTimestamps[data] = block.timestamp;
    }
}