contract SimpleStoragePointer {
    struct Data { uint value; }
    mapping(uint => Data) public dataMap;
    function update(uint key, uint newValue) public {
        Data storage d = dataMap[key];
        d.value = newValue;
    }
}