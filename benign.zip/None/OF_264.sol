contract SimpleFeeDistributor {
    function distributeFees(address[] memory recipients, uint256 totalFee) public {
        uint256 share = totalFee / recipients.length;
        // loop and transfer share
    }
}