contract SimpleBytesComparer {
    function compare(bytes memory a, bytes memory b) public pure returns (bool) {
        return keccak256(a) == keccak256(b);
    }
}