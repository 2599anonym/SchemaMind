contract SimpleTieredRateV2 {
    function getRateForAmount(uint256 amount) public pure returns (uint256) {
        if (amount > 1000) return 95; // 5% discount
        return 100;
    }
}