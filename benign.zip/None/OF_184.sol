contract SimpleAccessControlList {
    mapping(address => bool) public canAccess;
    function grantAccess(address user) public {
        canAccess[user] = true;
    }
}