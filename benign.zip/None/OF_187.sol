contract SimpleBytesStorage {
    bytes public data;
    function setData(bytes memory _data) public {
        data = _data;
    }
}