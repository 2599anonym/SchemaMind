contract SimpleRewardDistributorV2 {
    IERC20 public rewardToken;
    function distribute(address to, uint256 amount) public {
        rewardToken.transfer(to, amount);
    }
}