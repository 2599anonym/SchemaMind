contract SimpleConditionalLogicV2 {
    function check(uint256 a, uint256 b) public pure returns (bool) {
        if (a > b) {
            return true;
        }
        return false;
    }
}