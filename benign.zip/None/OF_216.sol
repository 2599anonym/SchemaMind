contract SimpleFeeOracle {
    uint public currentFee;
    function updateFee(uint _newFee) public {
        // access control
        currentFee = _newFee;
    }
}