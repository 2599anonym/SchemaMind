contract SimpleVestingContract {
    uint256 public immutable releaseTime;
    function isReleased() public view returns (bool) {
        return block.timestamp >= releaseTime;
    }
}