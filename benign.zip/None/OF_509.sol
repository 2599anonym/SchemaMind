contract SimpleDonationTrackerV2 {
    mapping(address => uint256) public donations;
    function myDonation() public view returns (uint256) {
        return donations[msg.sender];
    }
}