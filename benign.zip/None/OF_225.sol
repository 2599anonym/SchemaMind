contract SimpleStateReader {
    uint public value;
    function getValue() public view returns (uint) {
        return value;
    }
}