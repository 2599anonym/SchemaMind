contract SimpleContractAddressResolver {
    mapping(string => address) public contractAddresses;
    function resolve(string memory name) public view returns (address) {
        return contractAddresses[name];
    }
}