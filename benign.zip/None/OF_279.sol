contract SimpleTokenSale {
    uint public rate = 1000;
    function buyTokens() public payable {
        uint tokens = msg.value * rate;
        // token transfer logic
    }
}