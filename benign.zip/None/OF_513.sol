contract SimpleContractVersionV2 {
    string public constant VERSION = "2.0";
    function getVersion() public pure returns (string memory) {
        return VERSION;
    }
}