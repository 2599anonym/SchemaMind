contract MultiSig {
    address[] public owners;
    function isOwner(address user) public view returns (bool) {
        for (uint i = 0; i < owners.length; i++) {
            if (owners[i] == user) {
                return true;
            }
        }
        return false;
    }
}