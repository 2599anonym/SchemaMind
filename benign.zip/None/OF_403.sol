contract SimpleModifierWithArgs {
    mapping(address => uint) public levels;
    modifier requireLevel(uint _level) {
        require(levels[msg.sender] >= _level, "Insufficient level");
        _;
    }
    function specialAction() public requireLevel(5) {
        // logic for users with level 5+
    }
}