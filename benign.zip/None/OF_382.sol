contract SimpleInterface {
    interface ISimple {
        function getValue() external view returns (uint);
    }
}