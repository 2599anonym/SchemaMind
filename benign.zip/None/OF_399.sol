contract SimpleWhileLoop {
    function findPowerOfTwo(uint n) public pure returns (uint) {
        uint power = 1;
        while (power < n) {
            power *= 2;
        }
        return power;
    }
}