contract SimpleThresholdVoting {
    uint public votes;
    uint public constant VOTE_THRESHOLD = 100;
    function vote() public {
        votes++;
    }
    function execute() public {
        require(votes >= VOTE_THRESHOLD, "Threshold not met");
    }
}