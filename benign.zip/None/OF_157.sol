contract TieredPricing {
    function getPrice() public view returns (uint) {
        if (block.timestamp < 1672531200) { // Before 2023
            return 100;
        }
        return 200;
    }
}