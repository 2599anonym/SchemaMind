contract SimpleThresholdV2 {
    uint256 public value;
    function check(uint256 threshold) public view returns (bool) {
        return value >= threshold;
    }
}