contract SimpleClaim {
    mapping(address => bool) public hasClaimed;
    function claim() public {
        require(!hasClaimed[msg.sender], "Already claimed");
        hasClaimed[msg.sender] = true;
    }
}