contract SimpleRegistryWithCounter {
    mapping(address => bool) public isRegistered;
    uint public registeredCount;
    function register() public {
        if (!isRegistered[msg.sender]) {
            isRegistered[msg.sender] = true;
            registeredCount++;
        }
    }
}